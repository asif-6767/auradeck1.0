# AuraDeck

**Developer:** ASIF ISLAM (Independent Developer)  
**Application ID:** `com.asif.auradeck`  
**Version:** 1.0.0 (`versionCode = 1`)  
**Target Platform:** Android 13 (Primary: Symphony Innova 30, Non-Root), compatible with Android 7.0 – 15+ (Overlay + Freeform features target Android 12–15+)

---

## Overview

AuraDeck is a universal Android multitasking utility that provides a Realme-inspired **Smart Floating Sidebar** and **Native Freeform Window Launcher** without requiring root access, custom ROMs, or app cloning.

Users can enable a subtle edge handle along either the left or right edge of the screen, swipe inward to browse installed apps, and launch the **original installed application** (preserving its real package identity, storage, login sessions, settings, and notifications) using Android's native `ActivityOptions.setLaunchBounds(...)` freeform engine.

---

## Key Features

- **Smart Floating Sidebar (`FloatingSidebarService` + `SidebarOverlayController`)**:
  - Minimal vertical edge pill with rounded ends, configurable opacity, 3 appearance styles, auto-dimming, and persistent vertical position.
  - Supports Left or Right screen edges and respects screen orientation changes.
  - Smooth swipe-in launcher panel with search, Favorites, Recent apps, and alphabetical sorting.
- **Native Freeform Launch Engine (`FloatingLaunchEngine`)**:
  - Launches original installed applications via `ActivityOptions.setLaunchBounds(rect)` and `Display.DEFAULT_DISPLAY`.
  - Never clones, re-wraps, or simulates third-party apps.
  - Honest fallback detection: clearly informs the user when the host OS falls back to fullscreen (e.g., if OS Freeform Windowing is disabled).
- **Fixed Two-Size Proportional Windowing (`WindowBoundsCalculator`)**:
  - Exactly two predefined sizes (**Small Mode** and **Large Mode**) with uniform `1.28×` scaling so the window aspect ratio remains identical.
  - Minimal single top drag handle pill (no cluttered toolbars or resize corners) supporting smooth drag repositioning and double-tap toggling between Small and Large.
- **Premium Sound Effect System (`SoundEffectEngine`)**:
  - 7 original locally synthesized PCM WAV sound effects preloaded via `SoundPool` (`maxStreams = 1`) with master toggle, volume control, and Silent/Vibrate mode awareness.
- **Complete Jetpack Compose + Material 3 App**:
  - **Dashboard** (real permission & service telemetry, master switch, quick controls, recents)
  - **App Library** (search, Favorites, Recent, Freeform Ready filter, sticky A–Z sections)
  - **Settings** (Sidebar, Floating Window, Sound Effects, Appearance, Performance)
  - **Device Compatibility & Freeform Probe** (live OS diagnostic + `FreeformPocActivity`)
  - **About** (developer profile, build metadata, privacy commitment, open-source licenses)

---

## Build Instructions

### Prerequisites
- Android Studio Ladybug / Meerkat or Gradle 8.x+ with JDK 11+
- Android SDK Platform 36 (`compileSdk = 36`, `minSdk = 24`, `targetSdk = 36`)

### Build Debug APK
```bash
gradle :app:assembleDebug
```
Output APK: `app/build/outputs/apk/debug/app-debug.apk`

### Run Unit & Robolectric Tests
```bash
gradle :app:testDebugUnitTest
```

---

## Architecture

- `model/` — Immutable domain models, state enums, and proportional `WindowBoundsCalculator`
- `data/` — Jetpack DataStore Preferences (`SettingsRepository`)
- `system/` — `CompatibilityDetector`, `PermissionManager`, `AppDiscoveryRepository`, `FloatingLaunchEngine`
- `audio/` — Preloaded `SoundPool` synthesizer engine (`SoundEffectEngine`)
- `service/` — `FloatingSidebarService` (`specialUse` FGS), `SidebarOverlayController`, `BootCompletedReceiver`
- `ui/` — Material 3 theme (`Space Grotesk`, `Plus Jakarta Sans`, `JetBrains Mono`), `AuraDeckViewModel`, Compose screens, and `FreeformPocActivity`
