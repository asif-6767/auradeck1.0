# AuraDeck — Testing Report

**Application ID:** `com.asif.auradeck`  
**Version:** 1.0.0 (`versionCode = 1`)  
**Target Device Profile:** Symphony Innova 30 (Android 13, API 33, Non-Root)

---

## 1. Automated Verification Executed in Build Environment

All automated JVM unit tests, Robolectric Android 13/16 tests, and Debug APK assembly ran and passed cleanly (`gradle :app:testDebugUnitTest :app:assembleDebug`).

| Test Suite | Target SDK | Coverage | Status |
|---|---|---|---|
| `ExampleUnitTest` | JVM | Sanity arithmetic | **PASSED** |
| `ExampleRobolectricTest` | API 36 | Manifest & string resource resolution (`AuraDeck`) | **PASSED** |
| `WindowBoundsCalculatorTest` | API 33 | Two-size uniform scale factor (`1.28×`), exact aspect ratio preservation, safe screen margin clamping (`1080×2400`, `720×1600`) | **PASSED** |
| `AuraDeckRobolectricTest.application id and build metadata` | API 33 | Verifies `com.asif.auradeck` package identity and `AuraDeck` label | **PASSED** |
| `AuraDeckRobolectricTest.settings repository persists` | API 33 | DataStore persistence for edge, window size, theme mode, SFX volume, favorite packages, and recent apps LRU | **PASSED** |
| `AuraDeckRobolectricTest.compatibility detector` | API 33 | Honest `Settings.canDrawOverlays` reporting on Android 13 | **PASSED** |
| `AuraDeckRobolectricTest.cuj master switch & navigation` | API 33 | Verifies master switch without overlay opens rationale dialog (never fakes ON), plus Dashboard → Apps → Settings → About (`ASIF ISLAM`) Compose UI flows | **PASSED** |
| `gradle :app:assembleDebug` | API 36 | Full APK compilation, resource merging, icon mipmaps, raw WAV SFX, and debug signing | **PASSED** |

---

## 2. Physical Device Acceptance Checklist (Symphony Innova 30 / Android 13)

Because this cloud build container has no physical ADB or live hardware emulator attached, the following hardware-dependent behaviors are implemented and ready for physical device verification via the Streaming Emulator or APK sideload:

- Live `WindowManager` overlay touch drag, inward edge swipe, and outside-tap dismiss across third-party apps.
- Real `ActivityOptions.setLaunchBounds(...)` freeform window launch and double-tap SMALL ↔ LARGE top-pill resizing on the target ROM (dependent on OEM freeform feature or Developer Options *Enable freeform windows*).
- Hardware speaker playback of the 7 local WAV `SoundPool` assets and `BootCompletedReceiver` restoration across device reboot.
