package com.example.model

import android.graphics.Rect
import kotlin.math.min
import kotlin.math.roundToInt

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    DARK("Dark Charcoal"),
    LIGHT("Crisp Light")
}

enum class AccentStyle(val label: String) {
    ELECTRIC_VIOLET("Electric Violet"),
    COBALT_BLUE("Cobalt Blue"),
    AURORA_CYAN("Aurora Cyan")
}

enum class SidebarEdge(val label: String) {
    LEFT("Left Edge"),
    RIGHT("Right Edge")
}

enum class HandleAppearance(val label: String) {
    PILL_MINIMAL("Minimal White Pill"),
    GLOW_ACCENT("Aura Edge Glow"),
    FROSTED_GLASS("Frosted Graphite")
}

enum class FloatingWindowSize(val label: String) {
    SMALL("Small Mode"),
    LARGE("Large Mode")
}

enum class DragHandleBehavior(val label: String) {
    SMOOTH_FLOAT("Free Position"),
    SNAP_EDGES("Edge Magnetic Snap")
}

enum class AppResizeCompatibility(val label: String) {
    FREEFORM_READY("Freeform Ready"),
    FORCE_RESIZABLE("System Resizable"),
    FULLSCREEN_LIKELY("Fullscreen Only")
}

data class InstalledAppInfo(
    val packageName: String,
    val activityName: String,
    val appName: String,
    val isFavorite: Boolean = false,
    val isRecent: Boolean = false,
    val isSystemApp: Boolean = false,
    val resizeCompatibility: AppResizeCompatibility = AppResizeCompatibility.FORCE_RESIZABLE
)

enum class OverallCompatibilityLevel {
    NATIVE_FREEFORM_ACTIVE,
    OVERLAY_READY_FREEFORM_DISABLED,
    OVERLAY_PERMISSION_NEEDED
}

data class DeviceCompatibilityReport(
    val deviceManufacturer: String,
    val deviceModel: String,
    val androidVersionRelease: String,
    val sdkInt: Int,
    val canDrawOverlays: Boolean,
    val hasFreeformFeature: Boolean,
    val devFreeformSettingEnabled: Boolean,
    val supportsMultiWindow: Boolean,
    val postNotificationsGranted: Boolean,
    val ignoringBatteryOptimizations: Boolean,
    val isServiceRunning: Boolean,
    val overallLevel: OverallCompatibilityLevel,
    val summaryMessage: String
) {
    val isFreeformCapable: Boolean
        get() = hasFreeformFeature || devFreeformSettingEnabled
}

data class AuraDeckSettings(
    val sidebarEnabled: Boolean = false,
    val sidebarEdge: SidebarEdge = SidebarEdge.RIGHT,
    val sidebarYFraction: Float = 0.42f,
    val handleOpacity: Float = 0.85f,
    val handleAppearance: HandleAppearance = HandleAppearance.PILL_MINIMAL,
    val autoDimHandle: Boolean = true,
    val defaultWindowSize: FloatingWindowSize = FloatingWindowSize.SMALL,
    val doubleTapSizeSwitchEnabled: Boolean = true,
    val dragHandleBehavior: DragHandleBehavior = DragHandleBehavior.SMOOTH_FLOAT,
    val rememberWindowPosition: Boolean = true,
    val windowCenterXFraction: Float = 0.50f,
    val windowCenterYFraction: Float = 0.46f,
    val activeSessionWindowSize: FloatingWindowSize = FloatingWindowSize.SMALL,
    val sfxEnabled: Boolean = true,
    val sfxVolume: Float = 0.72f,
    val respectSilentMode: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentStyle: AccentStyle = AccentStyle.ELECTRIC_VIOLET,
    val favoritePackages: Set<String> = emptySet(),
    val recentPackages: List<String> = emptyList()
)

sealed class FloatingLaunchResult {
    data class NativeFreeformLaunched(
        val packageName: String,
        val appName: String,
        val windowSize: FloatingWindowSize,
        val bounds: Rect
    ) : FloatingLaunchResult()

    data class FullscreenFallbackLaunched(
        val packageName: String,
        val appName: String,
        val reason: String
    ) : FloatingLaunchResult()

    data class Failed(
        val packageName: String,
        val appName: String,
        val errorMessage: String
    ) : FloatingLaunchResult()
}

/**
 * Pure proportional two-size geometry engine.
 * Guarantees SMALL and LARGE share the exact same aspect ratio using uniform SCALE_FACTOR.
 */
object WindowBoundsCalculator {
    const val SCALE_FACTOR = 1.28f

    data class ProportionalPair(
        val smallWidth: Int,
        val smallHeight: Int,
        val largeWidth: Int,
        val largeHeight: Int,
        val aspectRatio: Float
    )

    fun computeProportionalSizes(
        displayWidth: Int,
        displayHeight: Int,
        safeMarginPx: Int
    ): ProportionalPair {
        val usableW = (displayWidth - safeMarginPx * 2).coerceAtLeast(320)
        val usableH = (displayHeight - safeMarginPx * 2).coerceAtLeast(480)

        // Adaptive portrait ratio derived from display proportions without forcing 9:16
        val displayPortraitRatio = min(usableW, usableH).toFloat() /
            maxOf(usableW, usableH).toFloat()
        val windowAspect = displayPortraitRatio.coerceIn(0.50f, 0.68f)

        // Max allowable large dimensions while staying smaller than the full display
        val maxLargeW = (usableW * 0.84f).roundToInt()
        val maxLargeH = (usableH * 0.78f).roundToInt()

        // Base large size respecting exact windowAspect
        val candidateLargeW = maxLargeW
        val candidateLargeH = (candidateLargeW / windowAspect).roundToInt()

        val (largeW, largeH) = if (candidateLargeH <= maxLargeH) {
            candidateLargeW to candidateLargeH
        } else {
            val adjustedH = maxLargeH
            val adjustedW = (adjustedH * windowAspect).roundToInt()
            adjustedW to adjustedH
        }

        // Uniform inverse scaling guarantees identical aspect ratio for SMALL mode
        val smallW = (largeW / SCALE_FACTOR).roundToInt().coerceAtLeast(220)
        val smallH = (largeH / SCALE_FACTOR).roundToInt().coerceAtLeast(320)

        return ProportionalPair(
            smallWidth = smallW,
            smallHeight = smallH,
            largeWidth = largeW,
            largeHeight = largeH,
            aspectRatio = smallW.toFloat() / smallH.toFloat()
        )
    }

    fun computeBounds(
        displayWidth: Int,
        displayHeight: Int,
        safeMarginPx: Int,
        size: FloatingWindowSize,
        centerXFraction: Float,
        centerYFraction: Float
    ): Rect {
        val pair = computeProportionalSizes(displayWidth, displayHeight, safeMarginPx)
        val targetW = if (size == FloatingWindowSize.SMALL) pair.smallWidth else pair.largeWidth
        val targetH = if (size == FloatingWindowSize.SMALL) pair.smallHeight else pair.largeHeight

        val maxLeft = (displayWidth - safeMarginPx - targetW).coerceAtLeast(safeMarginPx)
        val maxTop = (displayHeight - safeMarginPx - targetH).coerceAtLeast(safeMarginPx)

        val desiredLeft = (displayWidth * centerXFraction - targetW / 2f).roundToInt()
        val desiredTop = (displayHeight * centerYFraction - targetH / 2f).roundToInt()

        val left = desiredLeft.coerceIn(safeMarginPx, maxLeft)
        val top = desiredTop.coerceIn(safeMarginPx, maxTop)

        return Rect(left, top, left + targetW, top + targetH)
    }
}
