package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.ui.components.AuraCard
import com.example.ui.components.AuraDeckLogoMark
import com.example.ui.components.AuraSectionHeader
import com.example.ui.components.AuraStatusChip

@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    var showLicensesDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Product Hero Card
            item {
                AuraCard(highlighted = true) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        AuraDeckLogoMark(size = 60.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "AuraDeck",
                                style = MaterialTheme.typography.headlineLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Universal Floating App System",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AuraStatusChip(
                                    label = "v${BuildConfig.VERSION_NAME}",
                                    color = MaterialTheme.colorScheme.primary
                                )
                                AuraStatusChip(
                                    label = "Build ${BuildConfig.VERSION_CODE}",
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "AuraDeck is a modern Android multitasking project designed to make everyday smartphone use more convenient through smart floating access and a premium multitasking experience.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Developer Profile Card
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "Developer Profile",
                        subtitle = "Crafted with precision for non-root Android multitasking"
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            modifier = Modifier.size(54.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Person,
                                    contentDescription = "Developer avatar",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "ASIF ISLAM",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Independent Developer",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Build & Technology Metadata
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "Technology & Build",
                        subtitle = "Native Android stack without root privileges"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    InfoLine(label = "Application ID", value = BuildConfig.APPLICATION_ID)
                    InfoLine(label = "Version Name", value = BuildConfig.VERSION_NAME)
                    InfoLine(label = "Build Number", value = BuildConfig.VERSION_CODE.toString())
                    InfoLine(label = "UI Framework", value = "Kotlin + Jetpack Compose (Material 3)")
                    InfoLine(label = "Window Engine", value = "Android Freeform ActivityOptions + WindowManager")
                    InfoLine(label = "Settings Storage", value = "Jetpack DataStore Preferences (On-Device)")
                    InfoLine(label = "Audio Engine", value = "Android SoundPool (Local PCM WAV Assets)")
                }
            }

            // Privacy Explanation Card
            item {
                AuraCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Privacy & Security Architecture",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "• Zero account registration, zero cloud tracking, and zero analytics SDKs.\n" +
                            "• AuraDeck never captures screenshots, intercepts keystrokes, or accesses private storage of other applications.\n" +
                            "• Launched applications retain their original package identity, login sessions, notifications, and private data.\n" +
                            "• All sidebar, favorite, and sound preferences stay strictly local on your device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Credits, Copyright & Licenses
            item {
                AuraCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Credits & Open-Source Licenses",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Original UI sound effects synthesized locally for AuraDeck. Typography powered by Space Grotesk, Plus Jakarta Sans, and JetBrains Mono.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { showLicensesDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("about_licenses_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Description,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("View Open-Source Licenses")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "© 2026 ASIF ISLAM. All rights reserved for AuraDeck.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showLicensesDialog) {
        AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            icon = {
                Icon(imageVector = Icons.Rounded.Code, contentDescription = null)
            },
            title = {
                Text("Open-Source Licenses")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "AndroidX, Jetpack Compose, Material 3, Navigation Compose, Lifecycle, and DataStore Preferences — Apache License 2.0.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Kotlin Standard Library & Kotlinx Coroutines — Apache License 2.0.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Google Fonts (Space Grotesk, Plus Jakarta Sans, JetBrains Mono) — SIL Open Font License 1.1.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showLicensesDialog = false },
                    modifier = Modifier.testTag("licenses_close_button")
                ) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
