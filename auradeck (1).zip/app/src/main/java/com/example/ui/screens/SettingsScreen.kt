package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.DoNotDisturbOn
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.audio.AuraSoundEvent
import com.example.model.AccentStyle
import com.example.model.AuraDeckSettings
import com.example.model.DeviceCompatibilityReport
import com.example.model.DragHandleBehavior
import com.example.model.FloatingWindowSize
import com.example.model.HandleAppearance
import com.example.model.SidebarEdge
import com.example.model.ThemeMode
import com.example.model.WindowBoundsCalculator
import com.example.ui.components.AuraCard
import com.example.ui.components.AuraSectionHeader
import com.example.ui.components.AuraSegmentedOptions
import com.example.ui.components.AuraSettingToggleRow
import com.example.ui.components.AuraStatusChip
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.EmeraldReady
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AuraDeckSettings,
    compatibility: DeviceCompatibilityReport,
    isServiceRunning: Boolean,
    displayBoundsPx: Pair<Int, Int>,
    onToggleSidebar: (Boolean) -> Unit,
    onSetSidebarEdge: (SidebarEdge) -> Unit,
    onSetHandleOpacity: (Float) -> Unit,
    onSetHandleAppearance: (HandleAppearance) -> Unit,
    onSetAutoDimHandle: (Boolean) -> Unit,
    onSetDefaultWindowSize: (FloatingWindowSize) -> Unit,
    onSetDoubleTapSizeSwitch: (Boolean) -> Unit,
    onSetDragHandleBehavior: (DragHandleBehavior) -> Unit,
    onSetRememberWindowPosition: (Boolean) -> Unit,
    onSetSfxEnabled: (Boolean) -> Unit,
    onSetSfxVolume: (Float) -> Unit,
    onSetRespectSilentMode: (Boolean) -> Unit,
    onPreviewSound: (AuraSoundEvent) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetAccentStyle: (AccentStyle) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenCompatibility: () -> Unit,
    modifier: Modifier = Modifier
) {
    val proportionalPair = remember(displayBoundsPx) {
        WindowBoundsCalculator.computeProportionalSizes(
            displayWidth = displayBoundsPx.first,
            displayHeight = displayBoundsPx.second,
            safeMarginPx = 36
        )
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Every preference persists locally and updates the sidebar live.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // A. Sidebar Settings
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "A. Smart Sidebar",
                        subtitle = "Edge handle position, translucency, and visual style"
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    AuraSettingToggleRow(
                        title = "Enable Floating Sidebar",
                        subtitle = if (isServiceRunning) "Edge handle is live" else "Currently paused",
                        checked = settings.sidebarEnabled && compatibility.canDrawOverlays,
                        onCheckedChange = onToggleSidebar,
                        icon = Icons.Rounded.Layers,
                        testTag = "settings_sidebar_enable_switch"
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Screen Edge",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            SidebarEdge.LEFT to "Left Edge",
                            SidebarEdge.RIGHT to "Right Edge"
                        ),
                        selected = settings.sidebarEdge,
                        onSelect = onSetSidebarEdge,
                        testTagPrefix = "settings_edge"
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Handle Opacity",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${(settings.handleOpacity * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = settings.handleOpacity,
                        onValueChange = onSetHandleOpacity,
                        valueRange = 0.30f..1.0f,
                        modifier = Modifier.testTag("settings_handle_opacity_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Handle Appearance",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            HandleAppearance.PILL_MINIMAL to "Minimal",
                            HandleAppearance.GLOW_ACCENT to "Accent",
                            HandleAppearance.FROSTED_GLASS to "Frosted"
                        ),
                        selected = settings.handleAppearance,
                        onSelect = onSetHandleAppearance,
                        testTagPrefix = "settings_appearance"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSettingToggleRow(
                        title = "Auto-Dim Idle Handle",
                        subtitle = "Softly reduces handle visibility when untouched",
                        checked = settings.autoDimHandle,
                        onCheckedChange = onSetAutoDimHandle,
                        icon = Icons.Rounded.Visibility,
                        testTag = "settings_autodim_switch"
                    )
                }
            }

            // B. Floating Window Settings
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "B. Floating Window",
                        subtitle = "Fixed two-size proportional geometry (No free distortion)"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Default Launch Size",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            FloatingWindowSize.SMALL to "Small Mode",
                            FloatingWindowSize.LARGE to "Large Mode"
                        ),
                        selected = settings.defaultWindowSize,
                        onSelect = onSetDefaultWindowSize,
                        testTagPrefix = "settings_window_size"
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Proportional Aspect Lock (${WindowBoundsCalculator.SCALE_FACTOR}× Uniform Scale)",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Small: ${proportionalPair.smallWidth}×${proportionalPair.smallHeight} px   •   Large: ${proportionalPair.largeWidth}×${proportionalPair.largeHeight} px",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    AuraSettingToggleRow(
                        title = "Double-Tap Size Switching",
                        subtitle = "Double-tap the top drag handle to toggle Small ↔ Large",
                        checked = settings.doubleTapSizeSwitchEnabled,
                        onCheckedChange = onSetDoubleTapSizeSwitch,
                        icon = Icons.Rounded.TouchApp,
                        testTag = "settings_doubletap_switch"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Drag Handle Behavior",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            DragHandleBehavior.SMOOTH_FLOAT to "Free Float",
                            DragHandleBehavior.SNAP_EDGES to "Edge Snap"
                        ),
                        selected = settings.dragHandleBehavior,
                        onSelect = onSetDragHandleBehavior,
                        testTagPrefix = "settings_drag_behavior"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSettingToggleRow(
                        title = "Remember Window Position",
                        subtitle = "Restores last floating bounds across launches",
                        checked = settings.rememberWindowPosition,
                        onCheckedChange = onSetRememberWindowPosition,
                        icon = Icons.Rounded.Bookmark,
                        testTag = "settings_remember_pos_switch"
                    )
                }
            }

            // C. Sound Settings
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "C. Sound Effect System",
                        subtitle = "Locally synthesized harmonic UI chimes"
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    AuraSettingToggleRow(
                        title = "Master Sound Effects",
                        subtitle = "Plays soft tactile feedback on sidebar & window actions",
                        checked = settings.sfxEnabled,
                        onCheckedChange = onSetSfxEnabled,
                        icon = Icons.Rounded.VolumeUp,
                        testTag = "settings_sfx_master_switch"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SFX Volume",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${(settings.sfxVolume * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = settings.sfxVolume,
                        onValueChange = onSetSfxVolume,
                        enabled = settings.sfxEnabled,
                        valueRange = 0.0f..1.0f,
                        modifier = Modifier.testTag("settings_sfx_volume_slider")
                    )

                    AuraSettingToggleRow(
                        title = "Respect Device Silent Mode",
                        subtitle = "Mutes AuraDeck SFX when phone is on Vibrate or Silent",
                        checked = settings.respectSilentMode,
                        onCheckedChange = onSetRespectSilentMode,
                        icon = Icons.Rounded.DoNotDisturbOn,
                        testTag = "settings_silent_mode_switch"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Preview Sound Palette",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AuraSoundEvent.entries.forEach { event ->
                            AssistChip(
                                onClick = { onPreviewSound(event) },
                                label = { Text(event.label) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayCircle,
                                        contentDescription = "Play ${event.label}"
                                    )
                                },
                                modifier = Modifier.testTag("sfx_preview_${event.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // D. Appearance Settings
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "D. Appearance",
                        subtitle = "Theme mode and signature accent palette"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Theme Mode",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            ThemeMode.DARK to "Dark",
                            ThemeMode.LIGHT to "Light",
                            ThemeMode.SYSTEM to "System"
                        ),
                        selected = settings.themeMode,
                        onSelect = onSetThemeMode,
                        testTagPrefix = "settings_theme"
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Accent Style",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            AccentStyle.ELECTRIC_VIOLET to "Violet",
                            AccentStyle.COBALT_BLUE to "Cobalt",
                            AccentStyle.AURORA_CYAN to "Cyan"
                        ),
                        selected = settings.accentStyle,
                        onSelect = onSetAccentStyle,
                        testTagPrefix = "settings_accent"
                    )
                }
            }

            // E. Performance & Diagnostics
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "E. Performance & Compatibility",
                        subtitle = "Foreground service health and Android 13 battery guidance"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Memory,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Background Overlay Service",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        AuraStatusChip(
                            label = if (isServiceRunning) "RUNNING" else "STOPPED",
                            color = if (isServiceRunning) EmeraldReady else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.BatteryChargingFull,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Battery Optimization",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        AuraStatusChip(
                            label = if (compatibility.ignoringBatteryOptimizations) "UNRESTRICTED" else "OPTIMIZED",
                            color = if (compatibility.ignoringBatteryOptimizations) EmeraldReady else AmberWarn
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenBatterySettings,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_battery_btn")
                        ) {
                            Text("Battery Settings")
                        }
                        OutlinedButton(
                            onClick = onOpenCompatibility,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_compat_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inspector")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}
