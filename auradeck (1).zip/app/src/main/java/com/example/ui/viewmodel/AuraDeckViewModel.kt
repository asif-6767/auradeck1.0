package com.example.ui.viewmodel

import android.app.Application
import android.graphics.drawable.Drawable
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AuraSoundEvent
import com.example.audio.SoundEffectEngine
import com.example.data.SettingsRepository
import com.example.model.AccentStyle
import com.example.model.AppResizeCompatibility
import com.example.model.AuraDeckSettings
import com.example.model.DeviceCompatibilityReport
import com.example.model.DragHandleBehavior
import com.example.model.FloatingLaunchResult
import com.example.model.FloatingWindowSize
import com.example.model.HandleAppearance
import com.example.model.InstalledAppInfo
import com.example.model.SidebarEdge
import com.example.model.ThemeMode
import com.example.service.FloatingSidebarService
import com.example.system.AppDiscoveryRepository
import com.example.system.CompatibilityDetector
import com.example.system.FloatingLaunchEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryFilter(val label: String) {
    ALL("All"),
    FAVORITES("Favorites"),
    RECENT("Recent"),
    FREEFORM_READY("Freeform Ready")
}

sealed interface AppsUiState {
    data object Loading : AppsUiState
    data class Ready(
        val allApps: List<InstalledAppInfo>,
        val displayedApps: List<InstalledAppInfo>
    ) : AppsUiState
}

class AuraDeckViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val settingsRepository = SettingsRepository(appContext)
    private val appDiscoveryRepository = AppDiscoveryRepository(appContext)
    private val launchEngine = FloatingLaunchEngine(appContext)
    val soundEngine = SoundEffectEngine(appContext)

    val settings: StateFlow<AuraDeckSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = AuraDeckSettings()
    )

    private val _compatibility = MutableStateFlow(CompatibilityDetector.inspectDevice(appContext))
    val compatibility: StateFlow<DeviceCompatibilityReport> = _compatibility.asStateFlow()

    val isServiceRunning: StateFlow<Boolean> = FloatingSidebarService.isRunning

    private val _allApps = MutableStateFlow<List<InstalledAppInfo>?>(null)
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeFilter = MutableStateFlow(LibraryFilter.ALL)
    val activeFilter: StateFlow<LibraryFilter> = _activeFilter.asStateFlow()

    val appsState: StateFlow<AppsUiState> = combine(
        _allApps,
        _searchQuery,
        _activeFilter,
        settings
    ) { apps, query, filter, currentSettings ->
        if (apps == null) {
            AppsUiState.Loading
        } else {
            val recentSet = currentSettings.recentPackages.toSet()
            val merged = apps.map { app ->
                app.copy(
                    isFavorite = app.packageName in currentSettings.favoritePackages,
                    isRecent = app.packageName in recentSet
                )
            }
            val q = query.trim().lowercase()
            val filtered = merged.filter { app ->
                val matchesQuery = q.isEmpty() ||
                    app.appName.lowercase().contains(q) ||
                    app.packageName.lowercase().contains(q)
                val matchesFilter = when (filter) {
                    LibraryFilter.ALL -> true
                    LibraryFilter.FAVORITES -> app.isFavorite
                    LibraryFilter.RECENT -> app.isRecent
                    LibraryFilter.FREEFORM_READY ->
                        app.resizeCompatibility != AppResizeCompatibility.FULLSCREEN_LIKELY
                }
                matchesQuery && matchesFilter
            }
            val ordered = if (filter == LibraryFilter.RECENT) {
                val orderMap = currentSettings.recentPackages.withIndex().associate { it.value to it.index }
                filtered.sortedBy { orderMap[it.packageName] ?: Int.MAX_VALUE }
            } else {
                filtered
            }
            AppsUiState.Ready(allApps = merged, displayedApps = ordered)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = AppsUiState.Loading
    )

    private val _launchBanner = MutableStateFlow<String?>(null)
    val launchBanner: StateFlow<String?> = _launchBanner.asStateFlow()

    private val _showOverlayPermissionDialog = MutableStateFlow(false)
    val showOverlayPermissionDialog: StateFlow<Boolean> = _showOverlayPermissionDialog.asStateFlow()

    private var pendingEnableAfterOverlayGrant = false

    init {
        viewModelScope.launch {
            settings.collect { s ->
                soundEngine.enabled = s.sfxEnabled
                soundEngine.volume = s.sfxVolume
                soundEngine.respectSilentMode = s.respectSilentMode
            }
        }
        viewModelScope.launch {
            FloatingSidebarService.lastLaunchFeedback.collect { msg ->
                if (msg != null) _launchBanner.value = msg
            }
        }
        refreshInstalledApps()
        refreshSystemStatus()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            val s = settings.value
            val loaded = appDiscoveryRepository.loadInstalledApps(
                favoritePackages = s.favoritePackages,
                recentPackages = s.recentPackages
            )
            _allApps.value = loaded
        }
    }

    fun refreshSystemStatus() {
        val canDraw = Settings.canDrawOverlays(appContext)
        val currentSettings = settings.value
        viewModelScope.launch {
            if (!canDraw && currentSettings.sidebarEnabled) {
                settingsRepository.setSidebarEnabled(false)
                FloatingSidebarService.stop(appContext)
            } else if (canDraw && currentSettings.sidebarEnabled && !FloatingSidebarService.isRunning.value) {
                FloatingSidebarService.start(appContext)
            }
            _compatibility.value = CompatibilityDetector.inspectDevice(appContext)
        }
    }

    fun onResumeFromSettings() {
        val canDraw = Settings.canDrawOverlays(appContext)
        if (pendingEnableAfterOverlayGrant) {
            pendingEnableAfterOverlayGrant = false
            if (canDraw) {
                enableSidebarInternal()
            } else {
                _launchBanner.value = "Overlay permission was not granted. Sidebar stays disabled."
            }
        }
        refreshSystemStatus()
    }

    fun onToggleSidebarRequested(enable: Boolean) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        if (enable) {
            if (Settings.canDrawOverlays(appContext)) {
                enableSidebarInternal()
            } else {
                pendingEnableAfterOverlayGrant = true
                _showOverlayPermissionDialog.value = true
            }
        } else {
            pendingEnableAfterOverlayGrant = false
            viewModelScope.launch {
                settingsRepository.setSidebarEnabled(false)
                FloatingSidebarService.stop(appContext)
                _compatibility.value = CompatibilityDetector.inspectDevice(appContext)
            }
        }
    }

    private fun enableSidebarInternal() {
        viewModelScope.launch {
            settingsRepository.setSidebarEnabled(true)
            val started = FloatingSidebarService.start(appContext)
            if (!started) {
                settingsRepository.setSidebarEnabled(false)
                _launchBanner.value = "Could not start Floating Sidebar service. Check overlay & notification permissions."
            }
            _compatibility.value = CompatibilityDetector.inspectDevice(appContext)
        }
    }

    fun dismissOverlayPermissionDialog(clearPending: Boolean = false) {
        if (clearPending) {
            pendingEnableAfterOverlayGrant = false
        }
        _showOverlayPermissionDialog.value = false
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFilter(filter: LibraryFilter) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        _activeFilter.value = filter
    }

    fun toggleFavorite(packageName: String) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        viewModelScope.launch {
            settingsRepository.toggleFavoritePackage(packageName)
        }
    }

    fun launchApp(app: InstalledAppInfo) {
        soundEngine.play(AuraSoundEvent.APP_SELECT)
        val currentSettings = settings.value
        val targetSize = currentSettings.defaultWindowSize

        viewModelScope.launch {
            settingsRepository.recordRecentPackage(app.packageName)
            settingsRepository.setActiveSessionWindowSize(targetSize)
        }

        when (val result = launchEngine.launchApp(app, targetSize, currentSettings)) {
            is FloatingLaunchResult.NativeFreeformLaunched -> {
                soundEngine.play(AuraSoundEvent.FLOATING_LAUNCH)
                _launchBanner.value =
                    "Launched ${app.appName} in ${targetSize.label} (${result.bounds.width()}×${result.bounds.height()} px)"
            }
            is FloatingLaunchResult.FullscreenFallbackLaunched -> {
                soundEngine.play(AuraSoundEvent.FLOATING_LAUNCH)
                _launchBanner.value = result.reason
            }
            is FloatingLaunchResult.Failed -> {
                _launchBanner.value = result.errorMessage
            }
        }
    }

    fun runFreeformPoc() {
        soundEngine.play(AuraSoundEvent.FLOATING_LAUNCH)
        val currentSettings = settings.value
        when (val result = launchEngine.launchFreeformPoc(currentSettings.defaultWindowSize, currentSettings)) {
            is FloatingLaunchResult.NativeFreeformLaunched -> {
                _launchBanner.value =
                    "Freeform Probe launched (${result.bounds.width()}×${result.bounds.height()} px)."
            }
            is FloatingLaunchResult.FullscreenFallbackLaunched -> {
                _launchBanner.value = result.reason
            }
            is FloatingLaunchResult.Failed -> {
                _launchBanner.value = result.errorMessage
            }
        }
    }

    fun clearLaunchBanner() {
        _launchBanner.value = null
        FloatingSidebarService.lastLaunchFeedback.value = null
    }

    fun getAppIcon(packageName: String): Drawable? = appDiscoveryRepository.getAppIcon(packageName)

    fun setSidebarEdge(edge: SidebarEdge) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        viewModelScope.launch { settingsRepository.setSidebarEdge(edge) }
    }

    fun setHandleOpacity(opacity: Float) {
        viewModelScope.launch { settingsRepository.setHandleOpacity(opacity) }
    }

    fun setHandleAppearance(appearance: HandleAppearance) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        viewModelScope.launch { settingsRepository.setHandleAppearance(appearance) }
    }

    fun setAutoDimHandle(enabled: Boolean) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        viewModelScope.launch { settingsRepository.setAutoDimHandle(enabled) }
    }

    fun setDefaultWindowSize(size: FloatingWindowSize) {
        soundEngine.play(AuraSoundEvent.SIZE_SWITCH)
        viewModelScope.launch { settingsRepository.setDefaultWindowSize(size) }
    }

    fun setDoubleTapSizeSwitch(enabled: Boolean) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        viewModelScope.launch { settingsRepository.setDoubleTapSizeSwitchEnabled(enabled) }
    }

    fun setDragHandleBehavior(behavior: DragHandleBehavior) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        viewModelScope.launch { settingsRepository.setDragHandleBehavior(behavior) }
    }

    fun setRememberWindowPosition(remember: Boolean) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        viewModelScope.launch { settingsRepository.setRememberWindowPosition(remember) }
    }

    fun setSfxEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setSfxEnabled(enabled)
            if (enabled) {
                soundEngine.enabled = true
                soundEngine.play(AuraSoundEvent.TOGGLE, forcePreview = true)
            }
        }
    }

    fun setSfxVolume(volume: Float) {
        viewModelScope.launch { settingsRepository.setSfxVolume(volume) }
    }

    fun setRespectSilentMode(respect: Boolean) {
        soundEngine.play(AuraSoundEvent.TOGGLE)
        viewModelScope.launch { settingsRepository.setRespectSilentMode(respect) }
    }

    fun setThemeMode(mode: ThemeMode) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun setAccentStyle(style: AccentStyle) {
        soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        viewModelScope.launch { settingsRepository.setAccentStyle(style) }
    }

    fun previewSound(event: AuraSoundEvent) {
        soundEngine.play(event, forcePreview = true)
    }

    fun getDisplayBoundsPreview(): Pair<Int, Int> = launchEngine.getDisplayDimensionsPx()

    override fun onCleared() {
        soundEngine.release()
        super.onCleared()
    }
}
