package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Charcoal & Graphite Dark Surfaces
val CharcoalVoid = Color(0xFF0A0C12)
val CharcoalBase = Color(0xFF10131C)
val GraphiteSurface = Color(0xFF171C28)
val GraphiteElevated = Color(0xFF1F2636)
val GraphiteHighlight = Color(0xFF283145)
val SoftWhite = Color(0xFFF4F6FB)
val MutedSlate = Color(0xFF9BA5B8)
val SubtleOutlineDark = Color(0xFF2D364B)

// Crisp Slate Light Surfaces
val CloudLight = Color(0xFFF5F7FB)
val PureCardLight = Color(0xFFFFFFFF)
val SoftCardLight = Color(0xFFECEFF6)
val DeepInk = Color(0xFF111520)
val MutedInk = Color(0xFF566176)
val SubtleOutlineLight = Color(0xFFD6DCE8)

// Accent Palettes
val ElectricViolet = Color(0xFF7C5CFF)
val ElectricVioletBright = Color(0xFFA28BFF)
val ElectricVioletDeep = Color(0xFF5638D6)

val CobaltBlue = Color(0xFF3B82F6)
val CobaltBlueBright = Color(0xFF78AAFF)
val CobaltBlueDeep = Color(0xFF215FCC)

val AuroraCyan = Color(0xFF06B6D4)
val AuroraCyanBright = Color(0xFF5BE0F5)
val AuroraCyanDeep = Color(0xFF0889A1)

// Semantic Status Tokens
val EmeraldReady = Color(0xFF22C55E)
val EmeraldReadyMuted = Color(0xFF163826)
val AmberWarn = Color(0xFFF59E0B)
val AmberWarnMuted = Color(0xFF3A2A12)
val CoralAlert = Color(0xFFEF4444)
val CoralAlertMuted = Color(0xFF3B191E)
