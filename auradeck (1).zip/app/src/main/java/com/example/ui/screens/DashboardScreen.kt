package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.model.AuraDeckSettings
import com.example.model.DeviceCompatibilityReport
import com.example.model.FloatingWindowSize
import com.example.model.InstalledAppInfo
import com.example.model.OverallCompatibilityLevel
import com.example.model.SidebarEdge
import com.example.ui.components.AppDrawableIcon
import com.example.ui.components.AuraCard
import com.example.ui.components.AuraDeckLogoMark
import com.example.ui.components.AuraSectionHeader
import com.example.ui.components.AuraSegmentedOptions
import com.example.ui.components.AuraSettingToggleRow
import com.example.ui.components.AuraStatusChip
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.EmeraldReady

@Composable
fun DashboardScreen(
    settings: AuraDeckSettings,
    compatibility: DeviceCompatibilityReport,
    isServiceRunning: Boolean,
    recentApps: List<InstalledAppInfo>,
    getAppIcon: (String) -> Drawable?,
    onToggleSidebar: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRefreshStatus: () -> Unit,
    onSetEdge: (SidebarEdge) -> Unit,
    onSetDefaultSize: (FloatingWindowSize) -> Unit,
    onSetSfxEnabled: (Boolean) -> Unit,
    onLaunchApp: (InstalledAppInfo) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenCompatibility: () -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onRefreshStatus()
    }

    val actuallyActive = settings.sidebarEnabled && compatibility.canDrawOverlays && isServiceRunning

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Brand Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AuraDeckLogoMark(size = 42.dp)
                        Column {
                            Text(
                                text = "AuraDeck",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Smart Floating Window Deck",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    AuraStatusChip(
                        label = if (actuallyActive) "ACTIVE" else "STANDBY",
                        color = if (actuallyActive) EmeraldReady else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Hero Floating System Status & Master Toggle Card
            item {
                AuraCard(highlighted = actuallyActive) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(112.dp)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_auradeck_hero),
                            contentDescription = "AuraDeck abstract glass workspace artwork",
                            modifier = Modifier
                                .fillMaxSize()
                                .alpha(0.55f),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
                                            MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.45f)
                                        )
                                    )
                                )
                                .padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.CenterStart),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (actuallyActive) {
                                        "Smart Edge Handle Active"
                                    } else {
                                        "Floating Sidebar Ready"
                                    },
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (actuallyActive) {
                                        "Swipe from the ${settings.sidebarEdge.label.lowercase()} anywhere to open apps."
                                    } else if (!compatibility.canDrawOverlays) {
                                        "Grant overlay access to anchor the floating edge handle."
                                    } else {
                                        "Enable the edge handle to launch apps cleanly."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Floating Smart Sidebar",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = when {
                                    actuallyActive -> "Service running • ${settings.sidebarEdge.label}"
                                    settings.sidebarEnabled && !compatibility.canDrawOverlays ->
                                        "Disabled: Overlay permission missing"
                                    else -> "Tap to activate persistent edge handle"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Switch(
                            checked = actuallyActive,
                            onCheckedChange = onToggleSidebar,
                            modifier = Modifier.testTag("dashboard_master_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }

            // Permission & System Status Strip
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "System & Permission Status",
                        subtitle = "${compatibility.deviceManufacturer} ${compatibility.deviceModel} • Android ${compatibility.androidVersionRelease}"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    PermissionStatusRow(
                        title = "Display Over Other Apps",
                        granted = compatibility.canDrawOverlays,
                        grantedText = "Granted",
                        missingText = "Required for edge handle",
                        actionLabel = "Grant",
                        onAction = onRequestOverlayPermission,
                        testTag = "perm_overlay_action"
                    )

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val hasNotif = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        PermissionStatusRow(
                            title = "Service Notification (Android 13+)",
                            granted = hasNotif,
                            grantedText = "Allowed",
                            missingText = "Recommended for persistent service",
                            actionLabel = "Allow",
                            onAction = {
                                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            testTag = "perm_notif_action"
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val freeformLabel = when (compatibility.overallLevel) {
                        OverallCompatibilityLevel.NATIVE_FREEFORM_ACTIVE -> "Active on Device"
                        OverallCompatibilityLevel.OVERLAY_READY_FREEFORM_DISABLED -> "Disabled in OS Settings"
                        OverallCompatibilityLevel.OVERLAY_PERMISSION_NEEDED ->
                            if (compatibility.isFreeformCapable) "Supported" else "OS Freeform Off"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerLow)
                            .clickable(onClick = onOpenCompatibility)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (compatibility.isFreeformCapable) {
                                Icons.Rounded.CheckCircle
                            } else {
                                Icons.Rounded.WarningAmber
                            },
                            contentDescription = null,
                            tint = if (compatibility.isFreeformCapable) EmeraldReady else AmberWarn,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Native Freeform Windowing",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = freeformLabel,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = "Inspect compatibility",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Quick Settings Card
            item {
                AuraCard {
                    AuraSectionHeader(
                        title = "Quick Controls",
                        subtitle = "Instant adjustments synced to the floating deck"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Sidebar Edge",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            SidebarEdge.LEFT to "Left Edge",
                            SidebarEdge.RIGHT to "Right Edge"
                        ),
                        selected = settings.sidebarEdge,
                        onSelect = onSetEdge,
                        testTagPrefix = "quick_edge"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Default Floating Window Size",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSegmentedOptions(
                        options = listOf(
                            FloatingWindowSize.SMALL to "Small Mode",
                            FloatingWindowSize.LARGE to "Large Mode"
                        ),
                        selected = settings.defaultWindowSize,
                        onSelect = onSetDefaultSize,
                        testTagPrefix = "quick_size"
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    AuraSettingToggleRow(
                        title = "Interaction Sound Effects",
                        subtitle = "Subtle tactile chimes for sidebar & resize",
                        checked = settings.sfxEnabled,
                        onCheckedChange = onSetSfxEnabled,
                        icon = Icons.Rounded.VolumeUp,
                        testTag = "quick_sfx_switch"
                    )
                }
            }

            // Recently Used Applications
            item {
                AuraCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        AuraSectionHeader(
                            title = "Recently Launched",
                            subtitle = if (recentApps.isEmpty()) {
                                "Launch any app to pin it here"
                            } else {
                                "Tap to open in ${settings.defaultWindowSize.label}"
                            },
                            modifier = Modifier.weight(1f)
                        )
                        FilledTonalButton(
                            onClick = onOpenLibrary,
                            modifier = Modifier.testTag("dashboard_all_apps_button")
                        ) {
                            Text("All Apps")
                        }
                    }

                    AnimatedVisibility(
                        visible = recentApps.isNotEmpty(),
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(recentApps, key = { it.packageName }) { app ->
                                Surface(
                                    modifier = Modifier
                                        .width(86.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { onLaunchApp(app) }
                                        .testTag("recent_app_${app.packageName}"),
                                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        AppDrawableIcon(
                                            drawable = getAppIcon(app.packageName),
                                            contentDescription = app.appName,
                                            size = 44.dp
                                        )
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.labelLarge,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (recentApps.isEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onOpenLibrary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dashboard_browse_apps_cta"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Browse Installed Apps")
                        }
                    }
                }
            }

            // Shortcut Tiles Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ShortcutTile(
                        title = "App Library",
                        subtitle = "Search & Pin",
                        icon = Icons.Rounded.Apps,
                        onClick = onOpenLibrary,
                        testTag = "shortcut_library",
                        modifier = Modifier.weight(1f)
                    )
                    ShortcutTile(
                        title = "Compatibility",
                        subtitle = "OS & PoC Probe",
                        icon = Icons.Rounded.Shield,
                        onClick = onOpenCompatibility,
                        testTag = "shortcut_compatibility",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ShortcutTile(
                        title = "Settings",
                        subtitle = "Sidebar & SFX",
                        icon = Icons.Rounded.Tune,
                        onClick = onOpenSettings,
                        testTag = "shortcut_settings",
                        modifier = Modifier.weight(1f)
                    )
                    ShortcutTile(
                        title = "About",
                        subtitle = "ASIF ISLAM",
                        icon = Icons.Rounded.Info,
                        onClick = onOpenAbout,
                        testTag = "shortcut_about",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun PermissionStatusRow(
    title: String,
    granted: Boolean,
    grantedText: String,
    missingText: String,
    actionLabel: String,
    onAction: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
            contentDescription = null,
            tint = if (granted) EmeraldReady else CoralAlert,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (granted) grantedText else missingText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!granted) {
            OutlinedButton(
                onClick = onAction,
                modifier = Modifier.testTag(testTag)
            ) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    AuraCard(
        modifier = modifier.testTag(testTag),
        onClick = onClick
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
