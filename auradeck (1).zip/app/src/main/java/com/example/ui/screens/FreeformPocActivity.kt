package com.example.ui.screens

import android.content.res.Configuration
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.FloatingWindowSize
import com.example.system.CompatibilityDetector
import com.example.ui.theme.AuraDeckTheme
import com.example.ui.theme.EmeraldReady
import com.example.ui.theme.AmberWarn

/**
 * Real Android Activity launched via ActivityOptions.setLaunchBounds() in its own task affinity
 * to honestly verify whether the host device OS granted native Freeform Windowing or fell back to fullscreen.
 */
class FreeformPocActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REQUESTED_SIZE = "extra_requested_size"
        const val EXTRA_REQUESTED_BOUNDS = "extra_requested_bounds"
    }

    private var actualMultiWindow by mutableStateOf(false)
    private var configSummary by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        refreshWindowTelemetry()

        val requestedSize = intent?.getStringExtra(EXTRA_REQUESTED_SIZE) ?: FloatingWindowSize.SMALL.name
        val requestedBounds: Rect? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_REQUESTED_BOUNDS, Rect::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_REQUESTED_BOUNDS)
        }
        val compat = CompatibilityDetector.inspectDevice(this)

        setContent {
            AuraDeckTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .safeDrawingPadding()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Freeform Window Probe",
                                style = MaterialTheme.typography.titleLarge
                            )
                            IconButton(
                                onClick = { finish() },
                                modifier = Modifier.testTag("poc_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close probe window"
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (actualMultiWindow) Icons.Rounded.CheckCircle else Icons.Rounded.Info,
                                        contentDescription = null,
                                        tint = if (actualMultiWindow) EmeraldReady else AmberWarn
                                    )
                                    Text(
                                        text = if (actualMultiWindow) {
                                            "Active Multi-Window / Freeform Confirmed"
                                        } else {
                                            "OS Opened Fullscreen (Freeform Inactive)"
                                        },
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                Text(
                                    text = "Requested Mode: $requestedSize",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                requestedBounds?.let {
                                    Text(
                                        text = "Requested Launch Bounds: ${it.width()}×${it.height()} px at (${it.left}, ${it.top})",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Actual Window State: $configSummary",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Device Feature Freeform: ${compat.hasFreeformFeature} | Dev Flag: ${compat.devFreeformSettingEnabled}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = { finish() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("poc_done_button")
                        ) {
                            Text("Close Diagnostic Window")
                        }
                    }
                }
            }
        }
    }

    override fun onMultiWindowModeChanged(isInMultiWindowMode: Boolean, newConfig: Configuration) {
        super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig)
        refreshWindowTelemetry(newConfig)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshWindowTelemetry(newConfig)
    }

    private fun refreshWindowTelemetry(cfg: Configuration = resources.configuration) {
        actualMultiWindow = isInMultiWindowMode
        configSummary = "inMultiWindow=$actualMultiWindow, ${cfg.screenWidthDp}×${cfg.screenHeightDp}dp"
    }
}
