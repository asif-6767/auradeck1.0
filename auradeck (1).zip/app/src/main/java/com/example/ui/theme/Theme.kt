package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.model.AccentStyle
import com.example.model.ThemeMode

private fun buildDarkColorScheme(accent: AccentStyle) = when (accent) {
    AccentStyle.ELECTRIC_VIOLET -> darkColorScheme(
        primary = ElectricViolet,
        onPrimary = Color.White,
        primaryContainer = ElectricVioletDeep,
        onPrimaryContainer = ElectricVioletBright,
        secondary = CobaltBlue,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFF1D2C4D),
        onSecondaryContainer = CobaltBlueBright,
        tertiary = AuroraCyan,
        onTertiary = CharcoalVoid,
        background = CharcoalVoid,
        onBackground = SoftWhite,
        surface = CharcoalBase,
        onSurface = SoftWhite,
        surfaceVariant = GraphiteSurface,
        onSurfaceVariant = MutedSlate,
        surfaceContainerLow = GraphiteSurface,
        surfaceContainer = GraphiteElevated,
        surfaceContainerHigh = GraphiteHighlight,
        outline = SubtleOutlineDark,
        outlineVariant = Color(0xFF232B3D),
        error = CoralAlert,
        onError = Color.White
    )
    AccentStyle.COBALT_BLUE -> darkColorScheme(
        primary = CobaltBlue,
        onPrimary = Color.White,
        primaryContainer = CobaltBlueDeep,
        onPrimaryContainer = CobaltBlueBright,
        secondary = ElectricViolet,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFF2A2250),
        onSecondaryContainer = ElectricVioletBright,
        tertiary = AuroraCyan,
        onTertiary = CharcoalVoid,
        background = CharcoalVoid,
        onBackground = SoftWhite,
        surface = CharcoalBase,
        onSurface = SoftWhite,
        surfaceVariant = GraphiteSurface,
        onSurfaceVariant = MutedSlate,
        surfaceContainerLow = GraphiteSurface,
        surfaceContainer = GraphiteElevated,
        surfaceContainerHigh = GraphiteHighlight,
        outline = SubtleOutlineDark,
        outlineVariant = Color(0xFF232B3D),
        error = CoralAlert,
        onError = Color.White
    )
    AccentStyle.AURORA_CYAN -> darkColorScheme(
        primary = AuroraCyan,
        onPrimary = CharcoalVoid,
        primaryContainer = AuroraCyanDeep,
        onPrimaryContainer = AuroraCyanBright,
        secondary = CobaltBlue,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFF1D2C4D),
        onSecondaryContainer = CobaltBlueBright,
        tertiary = ElectricViolet,
        onTertiary = Color.White,
        background = CharcoalVoid,
        onBackground = SoftWhite,
        surface = CharcoalBase,
        onSurface = SoftWhite,
        surfaceVariant = GraphiteSurface,
        onSurfaceVariant = MutedSlate,
        surfaceContainerLow = GraphiteSurface,
        surfaceContainer = GraphiteElevated,
        surfaceContainerHigh = GraphiteHighlight,
        outline = SubtleOutlineDark,
        outlineVariant = Color(0xFF232B3D),
        error = CoralAlert,
        onError = Color.White
    )
}

private fun buildLightColorScheme(accent: AccentStyle) = when (accent) {
    AccentStyle.ELECTRIC_VIOLET -> lightColorScheme(
        primary = ElectricVioletDeep,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE9E4FF),
        onPrimaryContainer = Color(0xFF241366),
        secondary = CobaltBlueDeep,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFDDEAFF),
        onSecondaryContainer = Color(0xFF0E2A5C),
        tertiary = AuroraCyanDeep,
        onTertiary = Color.White,
        background = CloudLight,
        onBackground = DeepInk,
        surface = PureCardLight,
        onSurface = DeepInk,
        surfaceVariant = SoftCardLight,
        onSurfaceVariant = MutedInk,
        surfaceContainerLow = PureCardLight,
        surfaceContainer = SoftCardLight,
        surfaceContainerHigh = Color(0xFFE2E6F0),
        outline = SubtleOutlineLight,
        outlineVariant = Color(0xFFE6EAF2),
        error = CoralAlert,
        onError = Color.White
    )
    AccentStyle.COBALT_BLUE -> lightColorScheme(
        primary = CobaltBlueDeep,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFDDEAFF),
        onPrimaryContainer = Color(0xFF0E2A5C),
        secondary = ElectricVioletDeep,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFE9E4FF),
        onSecondaryContainer = Color(0xFF241366),
        tertiary = AuroraCyanDeep,
        onTertiary = Color.White,
        background = CloudLight,
        onBackground = DeepInk,
        surface = PureCardLight,
        onSurface = DeepInk,
        surfaceVariant = SoftCardLight,
        onSurfaceVariant = MutedInk,
        surfaceContainerLow = PureCardLight,
        surfaceContainer = SoftCardLight,
        surfaceContainerHigh = Color(0xFFE2E6F0),
        outline = SubtleOutlineLight,
        outlineVariant = Color(0xFFE6EAF2),
        error = CoralAlert,
        onError = Color.White
    )
    AccentStyle.AURORA_CYAN -> lightColorScheme(
        primary = AuroraCyanDeep,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFD6F7FC),
        onPrimaryContainer = Color(0xFF063742),
        secondary = CobaltBlueDeep,
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFDDEAFF),
        onSecondaryContainer = Color(0xFF0E2A5C),
        tertiary = ElectricVioletDeep,
        onTertiary = Color.White,
        background = CloudLight,
        onBackground = DeepInk,
        surface = PureCardLight,
        onSurface = DeepInk,
        surfaceVariant = SoftCardLight,
        onSurfaceVariant = MutedInk,
        surfaceContainerLow = PureCardLight,
        surfaceContainer = SoftCardLight,
        surfaceContainerHigh = Color(0xFFE2E6F0),
        outline = SubtleOutlineLight,
        outlineVariant = Color(0xFFE6EAF2),
        error = CoralAlert,
        onError = Color.White
    )
}

@Composable
fun AuraDeckTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    accentStyle: AccentStyle = AccentStyle.ELECTRIC_VIOLET,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colorScheme = if (isDark) buildDarkColorScheme(accentStyle) else buildLightColorScheme(accentStyle)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !isDark
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !isDark
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AuraDeckTypography,
        shapes = AuraDeckShapes,
        content = content
    )
}
