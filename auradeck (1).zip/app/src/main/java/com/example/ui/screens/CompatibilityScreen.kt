package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeveloperMode
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DeviceCompatibilityReport
import com.example.ui.components.AuraCard
import com.example.ui.components.AuraSectionHeader
import com.example.ui.components.AuraStatusChip
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.EmeraldReady

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompatibilityScreen(
    compatibility: DeviceCompatibilityReport,
    onBack: () -> Unit,
    onRunFreeformPoc: () -> Unit,
    onOpenDeveloperOptions: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Device Compatibility") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("compat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    AuraCard(highlighted = true) {
                        AuraSectionHeader(
                            title = "${compatibility.deviceManufacturer} ${compatibility.deviceModel}",
                            subtitle = "Android ${compatibility.androidVersionRelease} (API ${compatibility.sdkInt}) • Non-Root"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = compatibility.summaryMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onRunFreeformPoc,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("run_freeform_poc_button")
                        ) {
                            Icon(imageVector = Icons.Rounded.Science, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Run Native Freeform Probe")
                        }
                    }
                }

                item {
                    AuraCard {
                        AuraSectionHeader(
                            title = "Platform Capabilities",
                            subtitle = "Live Android system checks (never simulated)"
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        CapabilityLine(
                            label = "Overlay Permission (SYSTEM_ALERT_WINDOW)",
                            ok = compatibility.canDrawOverlays,
                            okText = "GRANTED",
                            noText = "MISSING"
                        )
                        CapabilityLine(
                            label = "OEM Freeform System Feature",
                            ok = compatibility.hasFreeformFeature,
                            okText = "PRESENT",
                            noText = "ABSENT"
                        )
                        CapabilityLine(
                            label = "Developer Freeform Flag (enable_freeform_support)",
                            ok = compatibility.devFreeformSettingEnabled,
                            okText = "ENABLED",
                            noText = "OFF"
                        )
                        CapabilityLine(
                            label = "Multi-Window Subsystem",
                            ok = compatibility.supportsMultiWindow,
                            okText = "SUPPORTED",
                            noText = "RESTRICTED"
                        )
                        CapabilityLine(
                            label = "Notifications Permission",
                            ok = compatibility.postNotificationsGranted,
                            okText = "ALLOWED",
                            noText = "DENIED"
                        )
                        CapabilityLine(
                            label = "Battery Optimization Unrestricted",
                            ok = compatibility.ignoringBatteryOptimizations,
                            okText = "UNRESTRICTED",
                            noText = "OPTIMIZED"
                        )
                    }
                }

                item {
                    AuraCard {
                        AuraSectionHeader(
                            title = "Android 13 Non-Root Guidance",
                            subtitle = "Important distinction for Symphony Innova 30 & AOSP ROMs"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "1. Overlay permission lets AuraDeck render its Smart Edge Handle and Floating Launcher over other apps.\n" +
                                "2. Launching third-party apps inside true floating windows without Root relies on Android's native Freeform Windowing (ActivityOptions.setLaunchBounds).\n" +
                                "3. On Android 13 phones where the manufacturer disabled Freeform by default, enabling 'Enable freeform windows' in Developer Options unlocks native floating windows for compatible apps.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onOpenOverlaySettings,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("compat_overlay_btn")
                            ) {
                                Text("Overlay Settings")
                            }
                            OutlinedButton(
                                onClick = onOpenDeveloperOptions,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("compat_dev_options_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeveloperMode,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Developer Opts")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityLine(
    label: String,
    ok: Boolean,
    okText: String,
    noText: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        AuraStatusChip(
            label = if (ok) okText else noText,
            color = if (ok) EmeraldReady else if (noText == "MISSING") CoralAlert else AmberWarn
        )
    }
}
