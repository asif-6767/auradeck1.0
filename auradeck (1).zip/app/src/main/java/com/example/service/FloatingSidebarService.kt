package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.SoundEffectEngine
import com.example.data.SettingsRepository
import com.example.system.AppDiscoveryRepository
import com.example.system.FloatingLaunchEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingSidebarService : Service() {

    companion object {
        const val CHANNEL_ID = "auradeck_sidebar_channel"
        const val NOTIFICATION_ID = 1042
        const val ACTION_START = "com.asif.auradeck.ACTION_START_SIDEBAR"
        const val ACTION_STOP = "com.asif.auradeck.ACTION_STOP_SIDEBAR"

        val isRunning = MutableStateFlow(false)
        val lastLaunchFeedback = MutableStateFlow<String?>(null)

        fun start(context: Context): Boolean {
            if (!Settings.canDrawOverlays(context)) return false
            val intent = Intent(context, FloatingSidebarService::class.java).apply {
                action = ACTION_START
            }
            return runCatching {
                ContextCompat.startForegroundService(context, intent)
                true
            }.getOrDefault(false)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingSidebarService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.stopService(intent) }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var soundEngine: SoundEffectEngine
    private lateinit var overlayController: SidebarOverlayController

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundSafely()

        if (!Settings.canDrawOverlays(this)) {
            isRunning.value = false
            stopSelf()
            return
        }

        settingsRepository = SettingsRepository(this)
        soundEngine = SoundEffectEngine(this)
        overlayController = SidebarOverlayController(
            context = this,
            scope = serviceScope,
            settingsRepository = settingsRepository,
            appDiscoveryRepository = AppDiscoveryRepository(this),
            launchEngine = FloatingLaunchEngine(this),
            soundEngine = soundEngine,
            onRequestStopService = {
                serviceScope.launch {
                    settingsRepository.setSidebarEnabled(false)
                    stopSelf()
                }
            }
        )

        isRunning.value = true

        serviceScope.launch {
            settingsRepository.settingsFlow.collectLatest { settings ->
                if (!settings.sidebarEnabled || !Settings.canDrawOverlays(this@FloatingSidebarService)) {
                    stopSelf()
                } else {
                    overlayController.attachOrUpdate(settings)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            serviceScope.launch {
                if (::settingsRepository.isInitialized) {
                    settingsRepository.setSidebarEnabled(false)
                }
                stopSelf()
            }
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            isRunning.value = false
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundSafely()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::overlayController.isInitialized) {
            overlayController.onConfigurationChanged()
        }
    }

    override fun onDestroy() {
        isRunning.value = false
        if (::overlayController.isInitialized) {
            overlayController.detachAll()
        }
        if (::soundEngine.isInitialized) {
            soundEngine.release()
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundSafely() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingSidebarService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(getString(R.string.service_notification_title))
            .setContentText(getString(R.string.service_notification_text))
            .setContentIntent(openPending)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(R.string.service_action_open), openPending)
            .addAction(0, getString(R.string.service_action_stop), stopPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.service_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.service_notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }
}
