package com.example.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.audio.AuraSoundEvent
import com.example.audio.SoundEffectEngine
import com.example.data.SettingsRepository
import com.example.model.AccentStyle
import com.example.model.AuraDeckSettings
import com.example.model.DragHandleBehavior
import com.example.model.FloatingLaunchResult
import com.example.model.FloatingWindowSize
import com.example.model.HandleAppearance
import com.example.model.InstalledAppInfo
import com.example.model.SidebarEdge
import com.example.model.ThemeMode
import com.example.system.AppDiscoveryRepository
import com.example.system.FloatingLaunchEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class SidebarOverlayController(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settingsRepository: SettingsRepository,
    private val appDiscoveryRepository: AppDiscoveryRepository,
    private val launchEngine: FloatingLaunchEngine,
    private val soundEngine: SoundEffectEngine,
    private val onRequestStopService: () -> Unit
) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val density = context.resources.displayMetrics.density
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private var edgeHandleContainer: FrameLayout? = null
    private var edgeHandlePill: View? = null
    private var edgeHandleParams: WindowManager.LayoutParams? = null

    private var launcherScrim: FrameLayout? = null
    private var launcherCard: LinearLayout? = null
    private var launcherParams: WindowManager.LayoutParams? = null

    private var windowDragHandleContainer: FrameLayout? = null
    private var windowDragHandleParams: WindowManager.LayoutParams? = null
    private var activeFloatingApp: InstalledAppInfo? = null
    private var activeFloatingSize: FloatingWindowSize = FloatingWindowSize.SMALL

    private var currentSettings = AuraDeckSettings()
    private var cachedApps: List<InstalledAppInfo> = emptyList()
    private var appsLoadJob: Job? = null

    private val autoDimRunnable = Runnable {
        if (currentSettings.autoDimHandle) {
            edgeHandlePill?.animate()?.alpha(0.40f)?.setDuration(280)?.start()
        }
    }

    fun attachOrUpdate(settings: AuraDeckSettings) {
        currentSettings = settings
        soundEngine.enabled = settings.sfxEnabled
        soundEngine.volume = settings.sfxVolume
        soundEngine.respectSilentMode = settings.respectSilentMode

        if (!Settings.canDrawOverlays(context)) {
            detachAll()
            onRequestStopService()
            return
        }

        if (edgeHandleContainer == null) {
            createEdgeHandle()
        } else {
            updateEdgeHandleAppearance()
        }
        preloadAppsIfNeeded()
    }

    fun onConfigurationChanged() {
        val (displayW, displayH) = launchEngine.getDisplayDimensionsPx()
        edgeHandleParams?.let { params ->
            params.x = 0
            params.y = computeEdgeHandleY(displayH, currentSettings.sidebarYFraction)
            params.gravity = Gravity.TOP or if (currentSettings.sidebarEdge == SidebarEdge.LEFT) {
                Gravity.START
            } else {
                Gravity.END
            }
            safeUpdateViewLayout(edgeHandleContainer, params)
        }
        if (launcherScrim != null) {
            dismissLauncherPanel(playSound = false)
        }
        windowDragHandleContainer?.let {
            val activeBounds = launchEngine.computeTargetBounds(activeFloatingSize, currentSettings)
            updateWindowDragHandlePosition(activeBounds, displayW)
        }
    }

    fun detachAll() {
        mainHandler.removeCallbacks(autoDimRunnable)
        appsLoadJob?.cancel()
        dismissLauncherPanel(playSound = false)
        removeWindowDragHandle()
        edgeHandleContainer?.let { safeRemoveView(it) }
        edgeHandleContainer = null
        edgeHandlePill = null
        edgeHandleParams = null
    }

    private fun preloadAppsIfNeeded() {
        appsLoadJob?.cancel()
        appsLoadJob = scope.launch {
            cachedApps = appDiscoveryRepository.loadInstalledApps(
                favoritePackages = currentSettings.favoritePackages,
                recentPackages = currentSettings.recentPackages
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createEdgeHandle() {
        val (_, displayH) = launchEngine.getDisplayDimensionsPx()
        val containerW = dp(28)
        val containerH = dp(86)

        val container = FrameLayout(context)
        val pill = View(context)
        val pillW = dp(5)
        val pillH = dp(64)
        val pillLp = FrameLayout.LayoutParams(pillW, pillH).apply {
            gravity = Gravity.CENTER_VERTICAL or if (currentSettings.sidebarEdge == SidebarEdge.LEFT) {
                Gravity.START
            } else {
                Gravity.END
            }
            marginStart = if (currentSettings.sidebarEdge == SidebarEdge.LEFT) dp(4) else 0
            marginEnd = if (currentSettings.sidebarEdge == SidebarEdge.RIGHT) dp(4) else 0
        }
        container.addView(pill, pillLp)

        val params = WindowManager.LayoutParams(
            containerW,
            containerH,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (currentSettings.sidebarEdge == SidebarEdge.LEFT) {
                Gravity.START
            } else {
                Gravity.END
            }
            x = 0
            y = computeEdgeHandleY(displayH, currentSettings.sidebarYFraction)
        }

        var downRawX = 0f
        var downRawY = 0f
        var startY = 0
        var isVerticalDragging = false
        var triggeredOpen = false

        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(autoDimRunnable)
                    pill.animate().alpha(currentSettings.handleOpacity).scaleX(1.18f).setDuration(120).start()
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startY = params.y
                    isVerticalDragging = false
                    triggeredOpen = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY

                    val inwardDx = if (currentSettings.sidebarEdge == SidebarEdge.LEFT) dx else -dx
                    if (!isVerticalDragging && !triggeredOpen && inwardDx > dp(22) && abs(dx) > abs(dy)) {
                        triggeredOpen = true
                        openLauncherPanel()
                        return@setOnTouchListener true
                    }

                    if (!triggeredOpen && (isVerticalDragging || abs(dy) > touchSlop && abs(dy) > abs(dx))) {
                        isVerticalDragging = true
                        val (_, h) = launchEngine.getDisplayDimensionsPx()
                        val minY = (h * 0.10f).roundToInt()
                        val maxY = (h * 0.82f).roundToInt()
                        params.y = (startY + dy.roundToInt()).coerceIn(minY, maxY)
                        safeUpdateViewLayout(container, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    pill.animate().scaleX(1f).setDuration(140).start()
                    scheduleAutoDim()
                    val totalDx = abs(event.rawX - downRawX)
                    val totalDy = abs(event.rawY - downRawY)
                    if (isVerticalDragging) {
                        val (_, h) = launchEngine.getDisplayDimensionsPx()
                        val frac = (params.y.toFloat() / h.coerceAtLeast(1)).coerceIn(0.12f, 0.85f)
                        scope.launch { settingsRepository.setSidebarYFraction(frac) }
                    } else if (!triggeredOpen && totalDx < touchSlop && totalDy < touchSlop) {
                        openLauncherPanel()
                    }
                    true
                }
                else -> false
            }
        }

        edgeHandleContainer = container
        edgeHandlePill = pill
        edgeHandleParams = params
        updateEdgeHandleAppearance()
        safeAddView(container, params)
        scheduleAutoDim()
    }

    private fun updateEdgeHandleAppearance() {
        val pill = edgeHandlePill ?: return
        val params = edgeHandleParams ?: return
        val (_, displayH) = launchEngine.getDisplayDimensionsPx()

        val isLeft = currentSettings.sidebarEdge == SidebarEdge.LEFT
        params.gravity = Gravity.TOP or if (isLeft) Gravity.START else Gravity.END
        params.y = computeEdgeHandleY(displayH, currentSettings.sidebarYFraction)

        (pill.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.gravity = Gravity.CENTER_VERTICAL or if (isLeft) Gravity.START else Gravity.END
            lp.marginStart = if (isLeft) dp(4) else 0
            lp.marginEnd = if (!isLeft) dp(4) else 0
            pill.layoutParams = lp
        }

        val accentHex = accentColorInt(currentSettings.accentStyle)
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(10).toFloat()
            when (currentSettings.handleAppearance) {
                HandleAppearance.PILL_MINIMAL -> {
                    setColor(Color.argb(235, 245, 247, 251))
                    setStroke(dp(1), Color.argb(70, 20, 24, 34))
                }
                HandleAppearance.GLOW_ACCENT -> {
                    setColor(accentHex)
                    setStroke(dp(1), Color.argb(140, 255, 255, 255))
                }
                HandleAppearance.FROSTED_GLASS -> {
                    setColor(Color.argb(190, 32, 38, 52))
                    setStroke(dp(1), Color.argb(160, 245, 247, 251))
                }
            }
        }
        pill.background = drawable
        pill.elevation = dp(4).toFloat()
        pill.alpha = currentSettings.handleOpacity

        safeUpdateViewLayout(edgeHandleContainer, params)
        scheduleAutoDim()
    }

    private fun scheduleAutoDim() {
        mainHandler.removeCallbacks(autoDimRunnable)
        if (currentSettings.autoDimHandle) {
            mainHandler.postDelayed(autoDimRunnable, 2400L)
        } else {
            edgeHandlePill?.alpha = currentSettings.handleOpacity
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun openLauncherPanel() {
        if (launcherScrim != null) return
        soundEngine.play(AuraSoundEvent.SIDEBAR_OPEN)

        val isDark = currentSettings.themeMode != ThemeMode.LIGHT
        val surfaceBg = if (isDark) Color.argb(246, 20, 24, 36) else Color.argb(246, 250, 251, 255)
        val cardItemBg = if (isDark) Color.argb(255, 30, 36, 52) else Color.argb(255, 236, 240, 248)
        val textPrimary = if (isDark) Color.rgb(244, 246, 251) else Color.rgb(17, 21, 32)
        val textMuted = if (isDark) Color.rgb(155, 165, 184) else Color.rgb(86, 97, 118)
        val accent = accentColorInt(currentSettings.accentStyle)

        val scrim = FrameLayout(context).apply {
            setBackgroundColor(Color.argb(75, 6, 8, 14))
        }

        val isLeft = currentSettings.sidebarEdge == SidebarEdge.LEFT
        val (displayW, displayH) = launchEngine.getDisplayDimensionsPx()
        val panelWidth = (displayW * 0.64f).roundToInt().coerceIn(dp(220), dp(290))
        val maxPanelHeight = (displayH * 0.68f).roundToInt()

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(12))
            elevation = dp(16).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(surfaceBg)
                setStroke(dp(1), Color.argb(55, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
        }

        // Header Row
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), dp(8))
        }
        val titleView = TextView(context).apply {
            text = "AuraDeck"
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sizeBadge = TextView(context).apply {
            text = if (activeFloatingSize == FloatingWindowSize.SMALL) "SMALL" else "LARGE"
            setTextColor(accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            paint.isFakeBoldText = true
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.argb(36, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            setOnClickListener {
                soundEngine.play(AuraSoundEvent.TOGGLE)
                activeFloatingSize = if (activeFloatingSize == FloatingWindowSize.SMALL) {
                    FloatingWindowSize.LARGE
                } else {
                    FloatingWindowSize.SMALL
                }
                text = if (activeFloatingSize == FloatingWindowSize.SMALL) "SMALL" else "LARGE"
                scope.launch { settingsRepository.setActiveSessionWindowSize(activeFloatingSize) }
            }
        }
        header.addView(titleView)
        header.addView(sizeBadge)
        card.addView(header)

        // Search input
        val searchBox = EditText(context).apply {
            hint = "Search installed apps..."
            setHintTextColor(textMuted)
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(cardItemBg)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }
        card.addView(searchBox)

        // Scrollable App List
        val scrollView = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val listContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        scrollView.addView(listContainer)
        card.addView(scrollView)

        fun populateList(query: String) {
            listContainer.removeAllViews()
            val q = query.trim().lowercase()
            val filtered = cachedApps.filter {
                q.isEmpty() || it.appName.lowercase().contains(q)
            }.sortedWith(
                compareByDescending<InstalledAppInfo> { it.isFavorite }
                    .thenByDescending { it.isRecent }
                    .thenBy(String.CASE_INSENSITIVE_ORDER) { it.appName }
            )

            if (filtered.isEmpty()) {
                val emptyText = TextView(context).apply {
                    text = if (cachedApps.isEmpty()) "Loading installed apps..." else "No matching apps"
                    setTextColor(textMuted)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(24), dp(12), dp(24))
                }
                listContainer.addView(emptyText)
                return
            }

            filtered.forEach { app ->
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(14).toFloat()
                        setColor(cardItemBg)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dp(6)
                    }
                    setOnClickListener {
                        soundEngine.play(AuraSoundEvent.APP_SELECT)
                        dismissLauncherPanel(playSound = false)
                        launchSelectedApp(app)
                    }
                }

                val iconView = ImageView(context).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                        marginEnd = dp(10)
                    }
                    setImageDrawable(appDiscoveryRepository.getAppIcon(app.packageName))
                }

                val labelCol = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                val nameTv = TextView(context).apply {
                    text = app.appName
                    setTextColor(textPrimary)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                    paint.isFakeBoldText = true
                    maxLines = 1
                }
                val tagTv = TextView(context).apply {
                    text = when {
                        app.isFavorite -> "Favorite • ${app.resizeCompatibility.label}"
                        app.isRecent -> "Recent • ${app.resizeCompatibility.label}"
                        else -> app.resizeCompatibility.label
                    }
                    setTextColor(textMuted)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                    maxLines = 1
                }
                labelCol.addView(nameTv)
                labelCol.addView(tagTv)

                row.addView(iconView)
                row.addView(labelCol)
                listContainer.addView(row)
            }
        }

        populateList("")
        if (cachedApps.isEmpty()) {
            scope.launch {
                cachedApps = appDiscoveryRepository.loadInstalledApps(
                    favoritePackages = currentSettings.favoritePackages,
                    recentPackages = currentSettings.recentPackages
                )
                mainHandler.post { populateList(searchBox.text?.toString().orEmpty()) }
            }
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                populateList(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val cardLp = FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_VERTICAL or if (isLeft) Gravity.START else Gravity.END
            marginStart = if (isLeft) dp(12) else dp(16)
            marginEnd = if (!isLeft) dp(12) else dp(16)
        }
        card.measure(
            View.MeasureSpec.makeMeasureSpec(panelWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(maxPanelHeight, View.MeasureSpec.AT_MOST)
        )
        if (card.measuredHeight > maxPanelHeight) {
            cardLp.height = maxPanelHeight
        }

        scrim.addView(card, cardLp)

        // Tap outside or swipe outward to dismiss
        var scrimDownX = 0f
        scrim.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    scrimDownX = event.rawX
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - scrimDownX
                    val outwardSwipe = if (isLeft) dx < -dp(24) else dx > dp(24)
                    if (outwardSwipe || abs(dx) < touchSlop) {
                        dismissLauncherPanel(playSound = true)
                    }
                    true
                }
                else -> false
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
            PixelFormat.TRANSLUCENT
        )

        launcherScrim = scrim
        launcherCard = card
        launcherParams = params
        safeAddView(scrim, params)

        card.translationX = if (isLeft) -panelWidth.toFloat() else panelWidth.toFloat()
        card.alpha = 0f
        card.animate()
            .translationX(0f)
            .alpha(1f)
            .setDuration(240L)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
    }

    private fun dismissLauncherPanel(playSound: Boolean) {
        val scrim = launcherScrim ?: return
        val card = launcherCard
        launcherScrim = null
        launcherCard = null
        launcherParams = null

        if (playSound) {
            soundEngine.play(AuraSoundEvent.SIDEBAR_CLOSE)
        }

        val isLeft = currentSettings.sidebarEdge == SidebarEdge.LEFT
        val shift = if (isLeft) -dp(260).toFloat() else dp(260).toFloat()
        if (card != null) {
            card.animate()
                .translationX(shift)
                .alpha(0f)
                .setDuration(180L)
                .withEndAction { safeRemoveView(scrim) }
                .start()
        } else {
            safeRemoveView(scrim)
        }
    }

    private fun launchSelectedApp(app: InstalledAppInfo) {
        val targetSize = currentSettings.defaultWindowSize
        activeFloatingSize = targetSize
        scope.launch {
            settingsRepository.recordRecentPackage(app.packageName)
            settingsRepository.setActiveSessionWindowSize(targetSize)
        }

        when (val result = launchEngine.launchApp(app, targetSize, currentSettings)) {
            is FloatingLaunchResult.NativeFreeformLaunched -> {
                soundEngine.play(AuraSoundEvent.FLOATING_LAUNCH)
                activeFloatingApp = app
                FloatingSidebarService.lastLaunchFeedback.value =
                    "Launched ${app.appName} in ${targetSize.label} (${result.bounds.width()}×${result.bounds.height()})"
                showMinimalTopDragHandle(result.bounds)
            }
            is FloatingLaunchResult.FullscreenFallbackLaunched -> {
                soundEngine.play(AuraSoundEvent.FLOATING_LAUNCH)
                activeFloatingApp = null
                removeWindowDragHandle()
                FloatingSidebarService.lastLaunchFeedback.value = result.reason
                mainHandler.post {
                    Toast.makeText(context, result.reason, Toast.LENGTH_LONG).show()
                }
            }
            is FloatingLaunchResult.Failed -> {
                activeFloatingApp = null
                removeWindowDragHandle()
                FloatingSidebarService.lastLaunchFeedback.value = result.errorMessage
                mainHandler.post {
                    Toast.makeText(context, result.errorMessage, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /**
     * Minimal single top drag handle (ONLY one small top pill — zero toolbars, zero extra buttons).
     * Dragging moves the floating window position; double-tapping switches SMALL <-> LARGE proportionally.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun showMinimalTopDragHandle(initialBounds: Rect) {
        removeWindowDragHandle()
        val (displayW, displayH) = launchEngine.getDisplayDimensionsPx()
        val handleW = dp(96)
        val handleH = dp(26)

        val container = FrameLayout(context)
        val pill = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(10).toFloat()
                setColor(Color.argb(235, 244, 246, 251))
                setStroke(dp(1), Color.argb(90, 20, 24, 34))
            }
            elevation = dp(4).toFloat()
        }
        val pillLp = FrameLayout.LayoutParams(dp(56), dp(6)).apply {
            gravity = Gravity.CENTER
        }
        container.addView(pill, pillLp)

        val params = WindowManager.LayoutParams(
            handleW,
            handleH,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (initialBounds.centerX() - handleW / 2).coerceIn(dp(8), (displayW - handleW - dp(8)).coerceAtLeast(dp(8)))
            y = (initialBounds.top - handleH / 2).coerceIn(dp(24), (displayH - handleH - dp(24)).coerceAtLeast(dp(24)))
        }

        val gestureDetector = GestureDetector(
            context,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    if (!currentSettings.doubleTapSizeSwitchEnabled) return false
                    toggleActiveWindowSize()
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    removeWindowDragHandle()
                }
            }
        )

        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        container.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    pill.animate().scaleX(1.12f).setDuration(100).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragging || abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        dragging = true
                        val (w, h) = launchEngine.getDisplayDimensionsPx()
                        params.x = (startX + dx.roundToInt()).coerceIn(dp(8), (w - handleW - dp(8)).coerceAtLeast(dp(8)))
                        params.y = (startY + dy.roundToInt()).coerceIn(dp(18), (h - handleH - dp(24)).coerceAtLeast(dp(18)))
                        safeUpdateViewLayout(container, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    pill.animate().scaleX(1.0f).setDuration(120).start()
                    if (dragging) {
                        val (w, h) = launchEngine.getDisplayDimensionsPx()
                        if (params.y <= dp(22)) {
                            removeWindowDragHandle()
                            return@setOnTouchListener true
                        }
                        if (currentSettings.dragHandleBehavior == DragHandleBehavior.SNAP_EDGES) {
                            val snappedX = if (params.x + handleW / 2 < w / 2) dp(18) else (w - handleW - dp(18))
                            animateHandleX(container, params, params.x, snappedX)
                        }
                        val app = activeFloatingApp
                        val activeBounds = launchEngine.computeTargetBounds(activeFloatingSize, currentSettings)
                        val newCenterX = ((params.x + handleW / 2f) / w.coerceAtLeast(1)).coerceIn(0.18f, 0.82f)
                        val newCenterY = ((params.y + handleH / 2f + activeBounds.height() / 2f) / h.coerceAtLeast(1))
                            .coerceIn(0.20f, 0.80f)
                        val updatedSettings = currentSettings.copy(
                            windowCenterXFraction = newCenterX,
                            windowCenterYFraction = newCenterY
                        )
                        currentSettings = updatedSettings
                        scope.launch {
                            if (updatedSettings.rememberWindowPosition) {
                                settingsRepository.setWindowCenterPosition(newCenterX, newCenterY)
                            }
                        }
                        if (app != null) {
                            launchEngine.launchApp(
                                app = app,
                                targetSize = activeFloatingSize,
                                settings = updatedSettings,
                                updateExistingTaskOnly = true
                            )
                        }
                    }
                    true
                }
                else -> false
            }
        }

        windowDragHandleContainer = container
        windowDragHandleParams = params
        safeAddView(container, params)
    }

    private fun toggleActiveWindowSize() {
        val app = activeFloatingApp ?: return
        val nextSize = if (activeFloatingSize == FloatingWindowSize.SMALL) {
            FloatingWindowSize.LARGE
        } else {
            FloatingWindowSize.SMALL
        }
        activeFloatingSize = nextSize
        soundEngine.play(AuraSoundEvent.SIZE_SWITCH)

        scope.launch { settingsRepository.setActiveSessionWindowSize(nextSize) }

        val result = launchEngine.launchApp(
            app = app,
            targetSize = nextSize,
            settings = currentSettings,
            updateExistingTaskOnly = true
        )
        if (result is FloatingLaunchResult.NativeFreeformLaunched) {
            val (displayW, _) = launchEngine.getDisplayDimensionsPx()
            updateWindowDragHandlePosition(result.bounds, displayW)
        }
    }

    private fun updateWindowDragHandlePosition(bounds: Rect, displayW: Int) {
        val container = windowDragHandleContainer ?: return
        val params = windowDragHandleParams ?: return
        val handleW = params.width
        val handleH = params.height
        val targetX = (bounds.centerX() - handleW / 2)
            .coerceIn(dp(8), (displayW - handleW - dp(8)).coerceAtLeast(dp(8)))
        val targetY = (bounds.top - handleH / 2).coerceAtLeast(dp(24))

        val animX = ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 220L
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                params.x = it.animatedValue as Int
                safeUpdateViewLayout(container, params)
            }
        }
        val animY = ValueAnimator.ofInt(params.y, targetY).apply {
            duration = 220L
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                params.y = it.animatedValue as Int
                safeUpdateViewLayout(container, params)
            }
        }
        animX.start()
        animY.start()
    }

    private fun animateHandleX(view: View, params: WindowManager.LayoutParams, fromX: Int, toX: Int) {
        ValueAnimator.ofInt(fromX, toX).apply {
            duration = 180L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                params.x = it.animatedValue as Int
                safeUpdateViewLayout(view, params)
            }
            start()
        }
    }

    private fun removeWindowDragHandle() {
        windowDragHandleContainer?.let { safeRemoveView(it) }
        windowDragHandleContainer = null
        windowDragHandleParams = null
    }

    private fun computeEdgeHandleY(displayH: Int, yFraction: Float): Int {
        return (displayH * yFraction).roundToInt()
            .coerceIn((displayH * 0.12f).roundToInt(), (displayH * 0.82f).roundToInt())
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun accentColorInt(style: AccentStyle): Int {
        return when (style) {
            AccentStyle.ELECTRIC_VIOLET -> Color.rgb(124, 92, 255)
            AccentStyle.COBALT_BLUE -> Color.rgb(59, 130, 246)
            AccentStyle.AURORA_CYAN -> Color.rgb(6, 182, 212)
        }
    }

    private fun dp(value: Int): Int = (value * density).roundToInt()

    private fun safeAddView(view: View, params: WindowManager.LayoutParams) {
        runCatching { windowManager.addView(view, params) }
    }

    private fun safeUpdateViewLayout(view: View?, params: WindowManager.LayoutParams) {
        if (view != null && view.isAttachedToWindow) {
            runCatching { windowManager.updateViewLayout(view, params) }
        }
    }

    private fun safeRemoveView(view: View) {
        if (view.isAttachedToWindow) {
            runCatching { windowManager.removeViewImmediate(view) }
        } else {
            runCatching { windowManager.removeView(view) }
        }
    }
}
