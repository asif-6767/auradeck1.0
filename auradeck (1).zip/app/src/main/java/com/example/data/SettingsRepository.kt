package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AccentStyle
import com.example.model.AuraDeckSettings
import com.example.model.DragHandleBehavior
import com.example.model.FloatingWindowSize
import com.example.model.HandleAppearance
import com.example.model.SidebarEdge
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.auraDeckDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "auradeck_settings"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val SIDEBAR_ENABLED = booleanPreferencesKey("sidebar_enabled")
        val SIDEBAR_EDGE = stringPreferencesKey("sidebar_edge")
        val SIDEBAR_Y_FRACTION = floatPreferencesKey("sidebar_y_fraction")
        val HANDLE_OPACITY = floatPreferencesKey("handle_opacity")
        val HANDLE_APPEARANCE = stringPreferencesKey("handle_appearance")
        val AUTO_DIM_HANDLE = booleanPreferencesKey("auto_dim_handle")
        val DEFAULT_WINDOW_SIZE = stringPreferencesKey("default_window_size")
        val DOUBLE_TAP_SIZE_SWITCH = booleanPreferencesKey("double_tap_size_switch")
        val DRAG_HANDLE_BEHAVIOR = stringPreferencesKey("drag_handle_behavior")
        val REMEMBER_WINDOW_POS = booleanPreferencesKey("remember_window_pos")
        val WINDOW_CENTER_X = floatPreferencesKey("window_center_x")
        val WINDOW_CENTER_Y = floatPreferencesKey("window_center_y")
        val ACTIVE_SESSION_SIZE = stringPreferencesKey("active_session_size")
        val SFX_ENABLED = booleanPreferencesKey("sfx_enabled")
        val SFX_VOLUME = floatPreferencesKey("sfx_volume")
        val RESPECT_SILENT_MODE = booleanPreferencesKey("respect_silent_mode")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_STYLE = stringPreferencesKey("accent_style")
        val FAVORITE_PACKAGES = stringSetPreferencesKey("favorite_packages")
        val RECENT_PACKAGES = stringPreferencesKey("recent_packages_csv")
    }

    val settingsFlow: Flow<AuraDeckSettings> = context.auraDeckDataStore.data.map { prefs ->
        AuraDeckSettings(
            sidebarEnabled = prefs[Keys.SIDEBAR_ENABLED] ?: false,
            sidebarEdge = prefs[Keys.SIDEBAR_EDGE].toEnum(SidebarEdge.RIGHT),
            sidebarYFraction = (prefs[Keys.SIDEBAR_Y_FRACTION] ?: 0.42f).coerceIn(0.12f, 0.85f),
            handleOpacity = (prefs[Keys.HANDLE_OPACITY] ?: 0.85f).coerceIn(0.30f, 1.0f),
            handleAppearance = prefs[Keys.HANDLE_APPEARANCE].toEnum(HandleAppearance.PILL_MINIMAL),
            autoDimHandle = prefs[Keys.AUTO_DIM_HANDLE] ?: true,
            defaultWindowSize = prefs[Keys.DEFAULT_WINDOW_SIZE].toEnum(FloatingWindowSize.SMALL),
            doubleTapSizeSwitchEnabled = prefs[Keys.DOUBLE_TAP_SIZE_SWITCH] ?: true,
            dragHandleBehavior = prefs[Keys.DRAG_HANDLE_BEHAVIOR].toEnum(DragHandleBehavior.SMOOTH_FLOAT),
            rememberWindowPosition = prefs[Keys.REMEMBER_WINDOW_POS] ?: true,
            windowCenterXFraction = (prefs[Keys.WINDOW_CENTER_X] ?: 0.50f).coerceIn(0.15f, 0.85f),
            windowCenterYFraction = (prefs[Keys.WINDOW_CENTER_Y] ?: 0.46f).coerceIn(0.15f, 0.85f),
            activeSessionWindowSize = prefs[Keys.ACTIVE_SESSION_SIZE].toEnum(FloatingWindowSize.SMALL),
            sfxEnabled = prefs[Keys.SFX_ENABLED] ?: true,
            sfxVolume = (prefs[Keys.SFX_VOLUME] ?: 0.72f).coerceIn(0.0f, 1.0f),
            respectSilentMode = prefs[Keys.RESPECT_SILENT_MODE] ?: true,
            themeMode = prefs[Keys.THEME_MODE].toEnum(ThemeMode.DARK),
            accentStyle = prefs[Keys.ACCENT_STYLE].toEnum(AccentStyle.ELECTRIC_VIOLET),
            favoritePackages = prefs[Keys.FAVORITE_PACKAGES] ?: emptySet(),
            recentPackages = prefs[Keys.RECENT_PACKAGES]
                ?.split(",")
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() }
                ?: emptyList()
        )
    }

    suspend fun setSidebarEnabled(enabled: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.SIDEBAR_ENABLED] = enabled }
    }

    suspend fun setSidebarEdge(edge: SidebarEdge) {
        context.auraDeckDataStore.edit { it[Keys.SIDEBAR_EDGE] = edge.name }
    }

    suspend fun setSidebarYFraction(fraction: Float) {
        context.auraDeckDataStore.edit {
            it[Keys.SIDEBAR_Y_FRACTION] = fraction.coerceIn(0.12f, 0.85f)
        }
    }

    suspend fun setHandleOpacity(opacity: Float) {
        context.auraDeckDataStore.edit {
            it[Keys.HANDLE_OPACITY] = opacity.coerceIn(0.30f, 1.0f)
        }
    }

    suspend fun setHandleAppearance(appearance: HandleAppearance) {
        context.auraDeckDataStore.edit { it[Keys.HANDLE_APPEARANCE] = appearance.name }
    }

    suspend fun setAutoDimHandle(enabled: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.AUTO_DIM_HANDLE] = enabled }
    }

    suspend fun setDefaultWindowSize(size: FloatingWindowSize) {
        context.auraDeckDataStore.edit {
            it[Keys.DEFAULT_WINDOW_SIZE] = size.name
            it[Keys.ACTIVE_SESSION_SIZE] = size.name
        }
    }

    suspend fun setActiveSessionWindowSize(size: FloatingWindowSize) {
        context.auraDeckDataStore.edit { it[Keys.ACTIVE_SESSION_SIZE] = size.name }
    }

    suspend fun setDoubleTapSizeSwitchEnabled(enabled: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.DOUBLE_TAP_SIZE_SWITCH] = enabled }
    }

    suspend fun setDragHandleBehavior(behavior: DragHandleBehavior) {
        context.auraDeckDataStore.edit { it[Keys.DRAG_HANDLE_BEHAVIOR] = behavior.name }
    }

    suspend fun setRememberWindowPosition(remember: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.REMEMBER_WINDOW_POS] = remember }
    }

    suspend fun setWindowCenterPosition(xFraction: Float, yFraction: Float) {
        context.auraDeckDataStore.edit {
            it[Keys.WINDOW_CENTER_X] = xFraction.coerceIn(0.15f, 0.85f)
            it[Keys.WINDOW_CENTER_Y] = yFraction.coerceIn(0.15f, 0.85f)
        }
    }

    suspend fun setSfxEnabled(enabled: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.SFX_ENABLED] = enabled }
    }

    suspend fun setSfxVolume(volume: Float) {
        context.auraDeckDataStore.edit { it[Keys.SFX_VOLUME] = volume.coerceIn(0.0f, 1.0f) }
    }

    suspend fun setRespectSilentMode(respect: Boolean) {
        context.auraDeckDataStore.edit { it[Keys.RESPECT_SILENT_MODE] = respect }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.auraDeckDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAccentStyle(style: AccentStyle) {
        context.auraDeckDataStore.edit { it[Keys.ACCENT_STYLE] = style.name }
    }

    suspend fun toggleFavoritePackage(packageName: String) {
        context.auraDeckDataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITE_PACKAGES]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(packageName)) {
                current.remove(packageName)
            }
            prefs[Keys.FAVORITE_PACKAGES] = current
        }
    }

    suspend fun recordRecentPackage(packageName: String) {
        context.auraDeckDataStore.edit { prefs ->
            val current = prefs[Keys.RECENT_PACKAGES]
                ?.split(",")
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() && it != packageName }
                ?.toMutableList()
                ?: mutableListOf()
            current.add(0, packageName)
            prefs[Keys.RECENT_PACKAGES] = current.take(12).joinToString(",")
        }
    }

    private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T {
        if (this == null) return default
        return runCatching { enumValueOf<T>(this) }.getOrDefault(default)
    }
}
