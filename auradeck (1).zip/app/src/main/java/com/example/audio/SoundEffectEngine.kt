package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import com.example.R
import java.util.EnumMap

enum class AuraSoundEvent(val label: String, val rawResId: Int) {
    SIDEBAR_OPEN("Sidebar Open", R.raw.sfx_sidebar_open),
    SIDEBAR_CLOSE("Sidebar Close", R.raw.sfx_sidebar_close),
    APP_SELECT("App Select", R.raw.sfx_app_select),
    FLOATING_LAUNCH("Floating Launch", R.raw.sfx_floating_launch),
    SIZE_SWITCH("Double-Tap Resize", R.raw.sfx_size_switch),
    TOGGLE("Toggle Switch", R.raw.sfx_toggle),
    SETTINGS_TAP("Settings Tap", R.raw.sfx_settings_tap)
}

class SoundEffectEngine(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val soundPool: SoundPool
    private val soundIds = EnumMap<AuraSoundEvent, Int>(AuraSoundEvent::class.java)
    private val loadedSounds = mutableSetOf<Int>()

    @Volatile var enabled: Boolean = true
    @Volatile var volume: Float = 0.72f
    @Volatile var respectSilentMode: Boolean = true

    private var activeStreamId: Int = 0
    private var lastPlayedAtMs: Long = 0L

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(attrs)
            .build()

        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
            }
        }

        AuraSoundEvent.entries.forEach { event ->
            val id = soundPool.load(appContext, event.rawResId, 1)
            soundIds[event] = id
        }
    }

    fun play(event: AuraSoundEvent, forcePreview: Boolean = false) {
        if (!forcePreview && !enabled) return
        if (!forcePreview && respectSilentMode && isDeviceSilent()) return

        val now = System.currentTimeMillis()
        if (!forcePreview && now - lastPlayedAtMs < 45L) return
        lastPlayedAtMs = now

        val soundId = soundIds[event] ?: return
        if (soundId !in loadedSounds) return

        val clampedVolume = volume.coerceIn(0f, 1f)
        if (clampedVolume <= 0.01f && !forcePreview) return
        val effectiveVol = if (forcePreview) clampedVolume.coerceAtLeast(0.35f) else clampedVolume

        if (activeStreamId != 0) {
            soundPool.stop(activeStreamId)
        }
        activeStreamId = soundPool.play(soundId, effectiveVol, effectiveVol, 1, 0, 1.0f)
    }

    fun isDeviceSilent(): Boolean {
        val mode = audioManager?.ringerMode ?: return false
        return mode == AudioManager.RINGER_MODE_SILENT || mode == AudioManager.RINGER_MODE_VIBRATE
    }

    fun release() {
        runCatching { soundPool.release() }
    }
}
