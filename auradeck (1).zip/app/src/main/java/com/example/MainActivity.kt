package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.audio.AuraSoundEvent
import com.example.system.PermissionManager
import com.example.ui.components.OverlayPermissionRationaleDialog
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AppLibraryScreen
import com.example.ui.screens.CompatibilityScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AuraDeckTheme
import com.example.ui.viewmodel.AppsUiState
import com.example.ui.viewmodel.AuraDeckViewModel

private sealed class AuraRoute(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Dashboard : AuraRoute(
        route = "dashboard",
        label = "Dashboard",
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard
    )

    data object Library : AuraRoute(
        route = "library",
        label = "Apps",
        selectedIcon = Icons.Filled.Apps,
        unselectedIcon = Icons.Outlined.Apps
    )

    data object Settings : AuraRoute(
        route = "settings",
        label = "Settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )

    data object About : AuraRoute(
        route = "about",
        label = "About",
        selectedIcon = Icons.Filled.Info,
        unselectedIcon = Icons.Outlined.Info
    )
}

private const val ROUTE_COMPATIBILITY = "compatibility"

class MainActivity : ComponentActivity() {

    private val viewModel: AuraDeckViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            AuraDeckTheme(
                themeMode = settings.themeMode,
                accentStyle = settings.accentStyle
            ) {
                AuraDeckAppShell(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AuraDeckAppShell(viewModel: AuraDeckViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val compatibility by viewModel.compatibility.collectAsStateWithLifecycle()
    val appsState by viewModel.appsState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val activeFilter by viewModel.activeFilter.collectAsStateWithLifecycle()
    val isServiceRunning by viewModel.isServiceRunning.collectAsStateWithLifecycle()
    val launchBanner by viewModel.launchBanner.collectAsStateWithLifecycle()
    val showOverlayDialog by viewModel.showOverlayPermissionDialog.collectAsStateWithLifecycle()

    // Recheck real permissions & service state whenever returning from Android System Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onResumeFromSettings()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(launchBanner) {
        val msg = launchBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearLaunchBanner()
        }
    }

    val topLevelTabs = remember {
        listOf(
            AuraRoute.Dashboard,
            AuraRoute.Library,
            AuraRoute.Settings,
            AuraRoute.About
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val isTopLevelRoute = currentDestination?.route in topLevelTabs.map { it.route }

    fun navigateToTab(route: String) {
        viewModel.soundEngine.play(AuraSoundEvent.SETTINGS_TAP)
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (isTopLevelRoute && !useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ) {
                        topLevelTabs.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("nav_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isTopLevelRoute && useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ) {
                        topLevelTabs.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("rail_${tab.route}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AuraRoute.Dashboard.route,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(AuraRoute.Dashboard.route) {
                        val recentApps = remember(appsState, settings.recentPackages) {
                            val all = (appsState as? AppsUiState.Ready)?.allApps.orEmpty()
                            val map = all.associateBy { it.packageName }
                            settings.recentPackages.mapNotNull { map[it] }
                        }
                        DashboardScreen(
                            settings = settings,
                            compatibility = compatibility,
                            isServiceRunning = isServiceRunning,
                            recentApps = recentApps,
                            getAppIcon = viewModel::getAppIcon,
                            onToggleSidebar = viewModel::onToggleSidebarRequested,
                            onRequestOverlayPermission = {
                                context.startActivity(PermissionManager.createOverlayPermissionIntent(context))
                            },
                            onRefreshStatus = viewModel::refreshSystemStatus,
                            onSetEdge = viewModel::setSidebarEdge,
                            onSetDefaultSize = viewModel::setDefaultWindowSize,
                            onSetSfxEnabled = viewModel::setSfxEnabled,
                            onLaunchApp = viewModel::launchApp,
                            onOpenLibrary = { navigateToTab(AuraRoute.Library.route) },
                            onOpenSettings = { navigateToTab(AuraRoute.Settings.route) },
                            onOpenCompatibility = { navController.navigate(ROUTE_COMPATIBILITY) },
                            onOpenAbout = { navigateToTab(AuraRoute.About.route) }
                        )
                    }

                    composable(AuraRoute.Library.route) {
                        AppLibraryScreen(
                            appsState = appsState,
                            searchQuery = searchQuery,
                            activeFilter = activeFilter,
                            defaultSize = settings.defaultWindowSize,
                            getAppIcon = viewModel::getAppIcon,
                            onSearchChange = viewModel::updateSearchQuery,
                            onSelectFilter = viewModel::selectFilter,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onLaunchApp = viewModel::launchApp
                        )
                    }

                    composable(AuraRoute.Settings.route) {
                        SettingsScreen(
                            settings = settings,
                            compatibility = compatibility,
                            isServiceRunning = isServiceRunning,
                            displayBoundsPx = viewModel.getDisplayBoundsPreview(),
                            onToggleSidebar = viewModel::onToggleSidebarRequested,
                            onSetSidebarEdge = viewModel::setSidebarEdge,
                            onSetHandleOpacity = viewModel::setHandleOpacity,
                            onSetHandleAppearance = viewModel::setHandleAppearance,
                            onSetAutoDimHandle = viewModel::setAutoDimHandle,
                            onSetDefaultWindowSize = viewModel::setDefaultWindowSize,
                            onSetDoubleTapSizeSwitch = viewModel::setDoubleTapSizeSwitch,
                            onSetDragHandleBehavior = viewModel::setDragHandleBehavior,
                            onSetRememberWindowPosition = viewModel::setRememberWindowPosition,
                            onSetSfxEnabled = viewModel::setSfxEnabled,
                            onSetSfxVolume = viewModel::setSfxVolume,
                            onSetRespectSilentMode = viewModel::setRespectSilentMode,
                            onPreviewSound = viewModel::previewSound,
                            onSetThemeMode = viewModel::setThemeMode,
                            onSetAccentStyle = viewModel::setAccentStyle,
                            onOpenBatterySettings = {
                                context.startActivity(PermissionManager.createBatteryOptimizationIntent(context))
                            },
                            onOpenCompatibility = { navController.navigate(ROUTE_COMPATIBILITY) }
                        )
                    }

                    composable(AuraRoute.About.route) {
                        AboutScreen()
                    }

                    composable(ROUTE_COMPATIBILITY) {
                        CompatibilityScreen(
                            compatibility = compatibility,
                            onBack = { navController.popBackStack() },
                            onRunFreeformPoc = viewModel::runFreeformPoc,
                            onOpenDeveloperOptions = {
                                context.startActivity(PermissionManager.createDeveloperOptionsIntent(context))
                            },
                            onOpenOverlaySettings = {
                                context.startActivity(PermissionManager.createOverlayPermissionIntent(context))
                            }
                        )
                    }
                }
            }
        }
    }

    if (showOverlayDialog) {
        OverlayPermissionRationaleDialog(
            onGrantClick = {
                viewModel.dismissOverlayPermissionDialog(clearPending = false)
                context.startActivity(PermissionManager.createOverlayPermissionIntent(context))
            },
            onDismiss = {
                viewModel.dismissOverlayPermissionDialog(clearPending = true)
            }
        )
    }
}
