package com.example.system

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.model.AppResizeCompatibility
import com.example.model.DeviceCompatibilityReport
import com.example.model.OverallCompatibilityLevel
import com.example.service.FloatingSidebarService

object CompatibilityDetector {

    fun inspectDevice(context: Context): DeviceCompatibilityReport {
        val pm = context.packageManager
        val canDrawOverlays = Settings.canDrawOverlays(context)
        val hasFreeformFeature = pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        val devFreeformEnabled = runCatching {
            Settings.Global.getInt(context.contentResolver, "enable_freeform_support", 0) == 1
        }.getOrDefault(false)

        val supportsMultiWindow = runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && am != null && !am.isLowRamDevice
        }.getOrDefault(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)

        val postNotificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val ignoringBatteryOpt = runCatching {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        }.getOrDefault(false)

        val isServiceRunning = FloatingSidebarService.isRunning.value

        val overallLevel = when {
            !canDrawOverlays -> OverallCompatibilityLevel.OVERLAY_PERMISSION_NEEDED
            hasFreeformFeature || devFreeformSettingEnabled(devFreeformEnabled) ->
                OverallCompatibilityLevel.NATIVE_FREEFORM_ACTIVE
            else -> OverallCompatibilityLevel.OVERLAY_READY_FREEFORM_DISABLED
        }

        val summary = when (overallLevel) {
            OverallCompatibilityLevel.NATIVE_FREEFORM_ACTIVE ->
                "Native Android Freeform Windowing and Smart Sidebar overlay are active on this device."
            OverallCompatibilityLevel.OVERLAY_READY_FREEFORM_DISABLED ->
                "Smart Sidebar overlay is ready. However, OS Freeform Windowing is disabled in Android system settings, so third-party apps may launch fullscreen until 'Enable freeform windows' is turned on in Developer Options."
            OverallCompatibilityLevel.OVERLAY_PERMISSION_NEEDED ->
                "Grant 'Display over other apps' permission to enable the floating edge handle."
        }

        return DeviceCompatibilityReport(
            deviceManufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            deviceModel = Build.MODEL,
            androidVersionRelease = Build.VERSION.RELEASE ?: "Unknown",
            sdkInt = Build.VERSION.SDK_INT,
            canDrawOverlays = canDrawOverlays,
            hasFreeformFeature = hasFreeformFeature,
            devFreeformSettingEnabled = devFreeformEnabled,
            supportsMultiWindow = supportsMultiWindow,
            postNotificationsGranted = postNotificationsGranted,
            ignoringBatteryOptimizations = ignoringBatteryOpt,
            isServiceRunning = isServiceRunning,
            overallLevel = overallLevel,
            summaryMessage = summary
        )
    }

    private fun devFreeformSettingEnabled(value: Boolean): Boolean = value

    fun inspectAppCompatibility(resolveInfo: ResolveInfo): AppResizeCompatibility {
        val activityInfo = resolveInfo.activityInfo ?: return AppResizeCompatibility.FORCE_RESIZABLE
        val appInfo = activityInfo.applicationInfo
        val targetSdk = appInfo?.targetSdkVersion ?: Build.VERSION_CODES.N

        return when {
            activityInfo.screenOrientation == ActivityInfo.SCREEN_ORIENTATION_LOCKED ->
                AppResizeCompatibility.FULLSCREEN_LIKELY
            targetSdk >= Build.VERSION_CODES.S ->
                AppResizeCompatibility.FREEFORM_READY
            targetSdk >= Build.VERSION_CODES.N ->
                AppResizeCompatibility.FORCE_RESIZABLE
            else ->
                AppResizeCompatibility.FULLSCREEN_LIKELY
        }
    }
}
