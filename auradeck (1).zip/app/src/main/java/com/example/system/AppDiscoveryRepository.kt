package com.example.system

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import com.example.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppDiscoveryRepository(context: Context) {

    private val appContext = context.applicationContext
    private val pm = appContext.packageManager

    // Memory-conscious LRU icon cache for silky-smooth scrolling on Android 13 devices
    private val iconCache = LruCache<String, Drawable>(160)

    suspend fun loadInstalledApps(
        favoritePackages: Set<String>,
        recentPackages: List<String>
    ): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveList: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                launcherIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }

        val seenPackages = HashSet<String>(resolveList.size)
        val apps = ArrayList<InstalledAppInfo>(resolveList.size)
        val recentSet = recentPackages.toSet()

        for (info in resolveList) {
            val activityInfo = info.activityInfo ?: continue
            val pkg = activityInfo.packageName ?: continue
            // Exclude AuraDeck itself and prevent duplicate package entries
            if (pkg == appContext.packageName || !seenPackages.add(pkg)) continue

            val label = runCatching { info.loadLabel(pm).toString().trim() }
                .getOrDefault(pkg)
                .ifEmpty { pkg }

            val isSystem = (activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val compat = CompatibilityDetector.inspectAppCompatibility(info)

            apps.add(
                InstalledAppInfo(
                    packageName = pkg,
                    activityName = activityInfo.name,
                    appName = label,
                    isFavorite = pkg in favoritePackages,
                    isRecent = pkg in recentSet,
                    isSystemApp = isSystem,
                    resizeCompatibility = compat
                )
            )
        }

        apps.sortWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.appName })
        apps
    }

    fun getAppIcon(packageName: String): Drawable? {
        iconCache.get(packageName)?.let { return it }
        val loaded = runCatching { pm.getApplicationIcon(packageName) }.getOrNull()
        if (loaded != null) {
            iconCache.put(packageName, loaded)
        }
        return loaded
    }

    fun getAppLabel(packageName: String): String {
        return runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(info).toString()
        }.getOrDefault(packageName)
    }

    fun clearIconCache() {
        iconCache.evictAll()
    }
}
