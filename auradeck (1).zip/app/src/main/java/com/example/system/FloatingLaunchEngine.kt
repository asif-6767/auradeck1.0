package com.example.system

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.example.model.AppResizeCompatibility
import com.example.model.AuraDeckSettings
import com.example.model.FloatingLaunchResult
import com.example.model.FloatingWindowSize
import com.example.model.InstalledAppInfo
import com.example.model.WindowBoundsCalculator
import com.example.ui.screens.FreeformPocActivity
import kotlin.math.roundToInt

class FloatingLaunchEngine(private val context: Context) {

    fun getDisplayDimensionsPx(): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        if (wm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            if (bounds.width() > 0 && bounds.height() > 0) {
                return bounds.width() to bounds.height()
            }
        }
        if (wm != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay?.getRealMetrics(metrics)
            if (metrics.widthPixels > 0 && metrics.heightPixels > 0) {
                return metrics.widthPixels to metrics.heightPixels
            }
        }
        val fallback = context.resources.displayMetrics
        return fallback.widthPixels.coerceAtLeast(1080) to fallback.heightPixels.coerceAtLeast(2400)
    }

    fun computeTargetBounds(
        size: FloatingWindowSize,
        settings: AuraDeckSettings
    ): Rect {
        val (displayW, displayH) = getDisplayDimensionsPx()
        val density = context.resources.displayMetrics.density
        val safeMarginPx = (14f * density).roundToInt()

        val centerX = if (settings.rememberWindowPosition) settings.windowCenterXFraction else 0.50f
        val centerY = if (settings.rememberWindowPosition) settings.windowCenterYFraction else 0.46f

        return WindowBoundsCalculator.computeBounds(
            displayWidth = displayW,
            displayHeight = displayH,
            safeMarginPx = safeMarginPx,
            size = size,
            centerXFraction = centerX,
            centerYFraction = centerY
        )
    }

    fun launchApp(
        app: InstalledAppInfo,
        targetSize: FloatingWindowSize,
        settings: AuraDeckSettings,
        updateExistingTaskOnly: Boolean = false
    ): FloatingLaunchResult {
        val launchIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (updateExistingTaskOnly) {
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            } else {
                addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            }
        }

        val bounds = computeTargetBounds(targetSize, settings)
        val options = buildFreeformActivityOptions(bounds)
        val compatReport = CompatibilityDetector.inspectDevice(context)

        return try {
            context.startActivity(launchIntent, options.toBundle())

            val nativeFreeformExpected = compatReport.isFreeformCapable &&
                app.resizeCompatibility != AppResizeCompatibility.FULLSCREEN_LIKELY

            if (nativeFreeformExpected) {
                FloatingLaunchResult.NativeFreeformLaunched(
                    packageName = app.packageName,
                    appName = app.appName,
                    windowSize = targetSize,
                    bounds = bounds
                )
            } else {
                val reason = if (!compatReport.isFreeformCapable) {
                    "Android Freeform Windowing is disabled in device settings — launched original app in fullscreen."
                } else {
                    "${app.appName} declares fixed/unresizable manifest flags — OS launched in fullscreen."
                }
                FloatingLaunchResult.FullscreenFallbackLaunched(
                    packageName = app.packageName,
                    appName = app.appName,
                    reason = reason
                )
            }
        } catch (se: SecurityException) {
            FloatingLaunchResult.Failed(
                packageName = app.packageName,
                appName = app.appName,
                errorMessage = "System denied launching ${app.appName}: ${se.localizedMessage ?: "Permission restricted"}"
            )
        } catch (t: Throwable) {
            FloatingLaunchResult.Failed(
                packageName = app.packageName,
                appName = app.appName,
                errorMessage = "Unable to launch ${app.appName}: ${t.localizedMessage ?: "Activity unavailable"}"
            )
        }
    }

    fun launchFreeformPoc(
        targetSize: FloatingWindowSize,
        settings: AuraDeckSettings
    ): FloatingLaunchResult {
        val bounds = computeTargetBounds(targetSize, settings)
        val pocIntent = Intent(context, FreeformPocActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            putExtra(FreeformPocActivity.EXTRA_REQUESTED_SIZE, targetSize.name)
            putExtra(FreeformPocActivity.EXTRA_REQUESTED_BOUNDS, bounds)
        }
        val options = buildFreeformActivityOptions(bounds)
        val compatReport = CompatibilityDetector.inspectDevice(context)

        return try {
            context.startActivity(pocIntent, options.toBundle())
            if (compatReport.isFreeformCapable) {
                FloatingLaunchResult.NativeFreeformLaunched(
                    packageName = context.packageName,
                    appName = "AuraDeck Freeform Probe",
                    windowSize = targetSize,
                    bounds = bounds
                )
            } else {
                FloatingLaunchResult.FullscreenFallbackLaunched(
                    packageName = context.packageName,
                    appName = "AuraDeck Freeform Probe",
                    reason = "OS Freeform Windowing is disabled on this ROM; probe will inspect actual window bounds."
                )
            }
        } catch (t: Throwable) {
            FloatingLaunchResult.Failed(
                packageName = context.packageName,
                appName = "AuraDeck Freeform Probe",
                errorMessage = t.localizedMessage ?: "Probe launch failed"
            )
        }
    }

    private fun buildFreeformActivityOptions(bounds: Rect): ActivityOptions {
        val options = ActivityOptions.makeBasic()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            options.setLaunchBounds(bounds)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            options.setLaunchDisplayId(Display.DEFAULT_DISPLAY)
        }
        return options
    }
}
