package com.example

import com.example.model.FloatingWindowSize
import com.example.model.WindowBoundsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class WindowBoundsCalculatorTest {

    @Test
    fun `small and large modes preserve exact aspect ratio on 1080x2400 display`() {
        val pair = WindowBoundsCalculator.computeProportionalSizes(
            displayWidth = 1080,
            displayHeight = 2400,
            safeMarginPx = 36
        )

        val smallAspect = pair.smallWidth.toFloat() / pair.smallHeight.toFloat()
        val largeAspect = pair.largeWidth.toFloat() / pair.largeHeight.toFloat()

        assertTrue("Small width must be smaller than large width", pair.smallWidth < pair.largeWidth)
        assertTrue("Small height must be smaller than large height", pair.smallHeight < pair.largeHeight)
        assertTrue("Large width must stay smaller than screen", pair.largeWidth < 1080)
        assertTrue("Large height must stay smaller than screen", pair.largeHeight < 2400)
        assertEquals(
            "Small and Large aspect ratios must match within rounding tolerance",
            smallAspect,
            largeAspect,
            0.01f
        )

        val actualScaleW = pair.largeWidth.toFloat() / pair.smallWidth.toFloat()
        val actualScaleH = pair.largeHeight.toFloat() / pair.smallHeight.toFloat()
        assertTrue(
            "Width and height must scale by the same uniform factor",
            abs(actualScaleW - actualScaleH) < 0.02f
        )
    }

    @Test
    fun `bounds stay inside safe screen margins across sizes and edge coordinates`() {
        val margin = 32
        val smallRect = WindowBoundsCalculator.computeBounds(
            displayWidth = 720,
            displayHeight = 1600,
            safeMarginPx = margin,
            size = FloatingWindowSize.SMALL,
            centerXFraction = 0.05f,
            centerYFraction = 0.95f
        )
        assertTrue(smallRect.left >= margin)
        assertTrue(smallRect.top >= margin)
        assertTrue(smallRect.right <= 720 - margin)
        assertTrue(smallRect.bottom <= 1600 - margin)

        val largeRect = WindowBoundsCalculator.computeBounds(
            displayWidth = 720,
            displayHeight = 1600,
            safeMarginPx = margin,
            size = FloatingWindowSize.LARGE,
            centerXFraction = 0.50f,
            centerYFraction = 0.50f
        )
        assertTrue(largeRect.width() > smallRect.width())
        assertTrue(largeRect.height() > smallRect.height())
    }
}
