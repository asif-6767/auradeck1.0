package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.SettingsRepository
import com.example.model.FloatingWindowSize
import com.example.model.SidebarEdge
import com.example.model.ThemeMode
import com.example.system.CompatibilityDetector
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33]) // Targets Android 13 (primary device target)
class AuraDeckRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `application id and build metadata match AuraDeck spec`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("com.asif.auradeck", context.packageName)
        assertEquals("AuraDeck", context.getString(R.string.app_name))
    }

    @Test
    fun `settings repository persists sidebar, window size, sfx, favorites, and recents`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = SettingsRepository(context)

        repo.setSidebarEdge(SidebarEdge.LEFT)
        repo.setDefaultWindowSize(FloatingWindowSize.LARGE)
        repo.setThemeMode(ThemeMode.LIGHT)
        repo.setSfxVolume(0.55f)
        repo.toggleFavoritePackage("com.android.calculator2")
        repo.recordRecentPackage("com.android.calculator2")

        val loaded = repo.settingsFlow.first()
        assertEquals(SidebarEdge.LEFT, loaded.sidebarEdge)
        assertEquals(FloatingWindowSize.LARGE, loaded.defaultWindowSize)
        assertEquals(ThemeMode.LIGHT, loaded.themeMode)
        assertEquals(0.55f, loaded.sfxVolume, 0.01f)
        assertTrue("com.android.calculator2" in loaded.favoritePackages)
        assertEquals("com.android.calculator2", loaded.recentPackages.firstOrNull())
    }

    @Test
    fun `compatibility detector reports overlay permission truthfully on Android 13`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val report = CompatibilityDetector.inspectDevice(context)
        assertEquals(33, report.sdkInt)
        assertFalse(report.canDrawOverlays)
    }

    @Test
    fun `cuj master switch without overlay shows permission dialog and navigation tabs work`() {
        composeRule.waitForIdle()

        // Dashboard visible
        composeRule.onNodeWithText("AuraDeck").assertIsDisplayed()

        // Tapping master switch without overlay permission prompts rationale dialog instead of faking ON
        composeRule.onNodeWithTag("dashboard_master_switch").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Display Over Other Apps Required").assertIsDisplayed()
        composeRule.onNodeWithTag("grant_overlay_cancel_button").performClick()
        composeRule.waitForIdle()

        // Navigate to Apps tab
        composeRule.onNodeWithTag("nav_library").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Installed App Library").assertIsDisplayed()

        // Navigate to Settings tab
        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("A. Smart Sidebar").assertIsDisplayed()

        // Navigate to About tab & verify ASIF ISLAM developer attribution
        composeRule.onNodeWithTag("nav_about").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("ASIF ISLAM").assertIsDisplayed()
        composeRule.onNodeWithText("Independent Developer").assertIsDisplayed()
    }
}
