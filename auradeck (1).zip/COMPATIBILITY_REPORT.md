# AuraDeck — Technical Feasibility & Compatibility Report

**Primary Target Device:** Symphony Innova 30 (Android 13, Non-Root)  
**Secondary Targets:** Android 12, Android 13, Android 14, Android 15+

---

## 1. Technical Feasibility Findings (Android 13, No Root)

### A. Smart Floating Edge Handle & Launcher (`SYSTEM_ALERT_WINDOW`)
- **Feasibility:** **Fully Supported** without root.
- **Mechanism:** `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` hosted inside a `specialUse` foreground service (`FloatingSidebarService`) with `POST_NOTIFICATIONS` on Android 13+.
- **Permissions:** Requires explicit user approval in Android's **Display over other apps** settings (`Settings.canDrawOverlays(context)`).

### B. Launching Original Third-Party Apps in Floating Windows (No Root)
- **Critical Architectural Truth:** `SYSTEM_ALERT_WINDOW` only permits drawing AuraDeck's own overlay views. Without root or privileged system permissions (`MANAGE_ACTIVITY_TASKS`), an ordinary app cannot embed another app's Activity surface inside its own overlay window.
- **Legitimate Native Android Mechanism:** `ActivityOptions.setLaunchBounds(rect)` combined with `Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK` (API 24+) and `setLaunchDisplayId(Display.DEFAULT_DISPLAY)` (API 28+).
- **Behavior on Symphony Innova 30 / Stock-Derived Android 13:**
  1. Many stock/Unisoc/MediaTek Android 13 builds ship with `PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT` set to `false` by default in firmware.
  2. When OS Freeform Windowing is disabled (`enable_freeform_support == 0`), `ActivityOptions.setLaunchBounds(...)` is ignored by ActivityTaskManager and the original third-party app opens **fullscreen** (while keeping its real identity, storage, login session, and notifications intact).
  3. Enabling **Developer Options -> Enable freeform windows** (`Settings.Global.enable_freeform_support = 1`) enables native AOSP freeform windows on Android 13 without root, allowing `ActivityOptions.setLaunchBounds(...)` to place compatible apps into genuine floating windows.
  4. Some third-party apps (e.g., locked-orientation games or `resizeableActivity="false"` manifests targeting older SDKs) may still be forced fullscreen by the OS window manager.

### C. AuraDeck's Honest Reporting Strategy
- AuraDeck probes `PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT`, `Settings.Global.enable_freeform_support`, `ActivityManager.isLowRamDevice`, and per-app manifest attributes via `CompatibilityDetector`.
- AuraDeck includes an interactive **`FreeformPocActivity`** ("Run Native Freeform Probe" in the Compatibility screen) that checks `Activity.isInMultiWindowMode` at runtime to verify actual OS behavior.
- If the OS falls back to fullscreen, AuraDeck reports the fallback transparently rather than simulating a fake floating window.

---

## 2. Per-OS Matrix

| Android Version | Smart Sidebar Overlay | Foreground Service Type | Native Freeform Windowing (`setLaunchBounds`) |
|---|---|---|---|
| **Android 12 (API 31–32)** | Supported (`SYSTEM_ALERT_WINDOW`) | Standard FGS | Supported when OEM feature or Developer freeform flag is enabled |
| **Android 13 (API 33 — Symphony Innova 30)** | Supported (`SYSTEM_ALERT_WINDOW`) | FGS + `POST_NOTIFICATIONS` | Supported when OEM feature or Developer Options *Enable freeform windows* is enabled; otherwise fullscreen fallback |
| **Android 14 (API 34)** | Supported | `specialUse` FGS declared | Supported when OEM/Developer freeform enabled |
| **Android 15+ (API 35–36)** | Supported | `specialUse` FGS declared | Enhanced desktop/freeform windowing on supported form factors |
